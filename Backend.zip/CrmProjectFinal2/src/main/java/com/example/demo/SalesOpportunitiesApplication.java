package com.example.demo;

import java.util.concurrent.TimeUnit;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.cache.CacheProperties.Caffeine;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.cache.CacheManager;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {"com.example.demo", "controller", "service.impl", "repository", "service", "payload", "entity"}, // Modified scanBasePackages
exclude = {SecurityAutoConfiguration.class})
@EntityScan(basePackages = {"entity"}) // Keep this as 'entity' might not be under com.example.demo
@EnableJpaRepositories(basePackages = {"repository"}) // Keep this as 'repository' might not be under com.example.demo
@EnableDiscoveryClient
public class SalesOpportunitiesApplication {
	    
    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }

    public static void main(String[] args) {
        SpringApplication.run(SalesOpportunitiesApplication.class, args);
    }
}