package config; // Recommended package: your_base_package.config
 
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
 
/**
* Global CORS configuration for the Spring Boot application.
* This class allows the Angular frontend (running on http://localhost:4200)
* to make requests to the backend API without being blocked by browser
* same-origin policy.
*/
@Configuration // Marks this class as a source of bean definitions
public class WebConfig implements WebMvcConfigurer {
 
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") // Apply CORS to all endpoints in the application
                .allowedOrigins("http://localhost:4200") // Explicitly allow requests from your Angular dev server
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS") // Allowed HTTP methods for requests
                .allowedHeaders("*") // Allow all headers in the request
                .allowCredentials(true) // Allow sending of cookies or authorization headers
                .maxAge(3600); // Max age (in seconds) for the pre-flight response cache
    }
}
 
 