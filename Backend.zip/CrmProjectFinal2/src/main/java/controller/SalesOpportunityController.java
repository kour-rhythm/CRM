package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import payload.SalesOpportunityDto;
import payload.SalesOpportunityResponseDto;
import service.SalesOpportunityService;
@CrossOrigin
@RestController
@RequestMapping("/api/salesopportunities")
public class SalesOpportunityController {

	private final SalesOpportunityService salesOppService;
	
	@Autowired
	public SalesOpportunityController(SalesOpportunityService salesOppService) {
		this.salesOppService = salesOppService;
	}

	@PostMapping
	public ResponseEntity<SalesOpportunityResponseDto> createSalesOpportunity(
			@RequestBody
			SalesOpportunityDto salesOppDto){
		SalesOpportunityResponseDto createdOpportunity = salesOppService.createSalesOpportunity(salesOppDto);
		return new ResponseEntity<>(createdOpportunity, HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<SalesOpportunityResponseDto>> getAllSalesOpportunities(){
		List<SalesOpportunityResponseDto> opportunities = salesOppService.getAllSalesOpportunities();
		return new ResponseEntity<>(opportunities, HttpStatus.OK);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<SalesOpportunityResponseDto> getSalesOpportunityById(
            @PathVariable Long id) {
        return salesOppService.getSalesOpportunityById(id)
                .map(opportunity -> new ResponseEntity<>(opportunity, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
	
	@PutMapping("/{id}")
    public ResponseEntity<SalesOpportunityResponseDto> updateSalesOpportunity(
            @PathVariable Long id,
            @RequestBody
            SalesOpportunityDto salesOpportunityDTO) {
        return salesOppService.updateSalesOpportunity(id, salesOpportunityDTO)
                .map(opportunity -> new ResponseEntity<>(opportunity, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
	
	@DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSalesOpportunity(
            @PathVariable Long id) {
        salesOppService.deleteSalesOpportunity(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
	@PostMapping("/{id}/track-activity")
    public ResponseEntity<String> trackActivity(
            @PathVariable Long id,
            @RequestBody
            String activityDetails) {
        salesOppService.trackSalesActivity(id, activityDetails);
        return new ResponseEntity<>("Activity tracked for opportunity " + id, HttpStatus.OK);
    }

}
