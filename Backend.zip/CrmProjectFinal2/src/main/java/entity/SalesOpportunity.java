package entity; // This must match your folder path: src/main/java/com/model

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Column;
import jakarta.persistence.Table; // Import for @Table annotation
import java.time.LocalDate;


@Entity 
@Table(name = "sales_opportunity") 
public class SalesOpportunity { 
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long id; 

    @Column(nullable = false) 
    private String name; 

    @Column(nullable = false) 
    private String stage; 

    private Double amount;

    private LocalDate closeDate; 

    private String leadSource; 

    @Column(length = 1000)
    private String notes; 

    public SalesOpportunity() {
    }

    
    public SalesOpportunity(String name, String stage, Double amount, LocalDate closeDate, String leadSource, String notes) {
        this.name = name;
        this.stage = stage;
        this.amount = amount;
        this.closeDate = closeDate;
        this.leadSource = leadSource;
        this.notes = notes;
    }



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public LocalDate getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(LocalDate closeDate) {
        this.closeDate = closeDate;
    }

    public String getLeadSource() {
        return leadSource;
    }

    public void setLeadSource(String leadSource) {
        this.leadSource = leadSource;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    @Override
    public String toString() {
        return "SalesOpportunity{" +
               "id=" + id +
               ", name='" + name + '\'' +
               ", stage='" + stage + '\'' +
               ", amount=" + amount +
               ", closeDate=" + closeDate +
               ", leadSource='" + leadSource + '\'' +
               ", notes='" + notes + '\'' +
               '}';
    }
}