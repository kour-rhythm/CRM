package payload;

import java.time.LocalDate; 


public class SalesOpportunityDto {

	private String name; 
	private String stage; 
	private Double amount; 
	private LocalDate closeDate; 
	private String leadSource; 
	private String notes; 
	
	
	public SalesOpportunityDto() {
		
	}
	
	
    public SalesOpportunityDto(String name, String stage, Double amount, LocalDate closeDate, String leadSource, String notes) {
        this.name = name;
        this.stage = stage;
        this.amount = amount;
        this.closeDate = closeDate;
        this.leadSource = leadSource;
        this.notes = notes;
    }
	
	public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public LocalDate getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(LocalDate closeDate) {
        this.closeDate = closeDate;
    }

    public String getLeadSource() {
        return leadSource;
    }

    public void setLeadSource(String leadSource) {
        this.leadSource = leadSource;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
    
    
    @Override
    public String toString() {
        return "SalesOpportunityDTO{" +
               "name='" + name + '\'' +
               ", stage='" + stage + '\'' +
               ", amount=" + amount +
               ", closeDate=" + closeDate +
               ", leadSource='" + leadSource + '\'' +
               ", notes='" + notes + '\'' +
               '}';
    }
}
