package payload;

import java.time.LocalDate;


public class SalesOpportunityResponseDto {

	private Long id; 
    private String name; 
    private String stage; 
    private Double amount; 
    private LocalDate closeDate;
    private String leadSource; 
    private String notes; 

    
    public SalesOpportunityResponseDto() {
    }

    public SalesOpportunityResponseDto(Long id, String name, String stage, Double amount, LocalDate closeDate, String leadSource, String notes) {
        this.id = id;
        this.name = name;
        this.stage = stage;
        this.amount = amount;
        this.closeDate = closeDate;
        this.leadSource = leadSource;
        this.notes = notes;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public LocalDate getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(LocalDate closeDate) {
        this.closeDate = closeDate;
    }

    public String getLeadSource() {
        return leadSource;
    }

    public void setLeadSource(String leadSource) {
        this.leadSource = leadSource;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    @Override
    public String toString() {
        return "SalesOpportunityResponseDTO{" +
               "id=" + id +
               ", name='" + name + '\'' +
               ", stage='" + stage + '\'' +
               ", amount=" + amount +
               ", closeDate=" + closeDate +
               ", leadSource='" + leadSource + '\'' +
               ", notes='" + notes + '\'' +
               '}';
    }
}
