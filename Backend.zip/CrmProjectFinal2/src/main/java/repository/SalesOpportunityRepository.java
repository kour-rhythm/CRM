package repository; 
import entity.SalesOpportunity;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository 
public interface SalesOpportunityRepository extends JpaRepository<SalesOpportunity, Long> { // This interface name MUST match your file name: SalesOpportunityRepository.java

}

