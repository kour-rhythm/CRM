package service;

import payload.SalesOpportunityDto;
import payload.SalesOpportunityResponseDto;

import java.util.List;
import java.util.Optional;

/**
 * Interface for the Sales Opportunity Service.
 * Defines the contract for managing sales opportunities,
 * abstracting the business logic implementation details.
 */
public interface SalesOpportunityService {

    /**
     * Creates a new sales opportunity.
     * @param opportunityDTO The DTO containing data for the new sales opportunity.
     * @return The DTO of the newly created sales opportunity.
     */
    SalesOpportunityResponseDto createSalesOpportunity(SalesOpportunityDto opportunityDTO); // Corrected signature

    /**
     * Retrieves all sales opportunities.
     * @return A list of DTOs representing all sales opportunities.
     */
    List<SalesOpportunityResponseDto> getAllSalesOpportunities();

    /**
     * Retrieves a sales opportunity by its ID.
     * @param id The ID of the sales opportunity to retrieve.
     * @return An Optional containing the DTO of the sales opportunity if found, otherwise empty.
     */
    Optional<SalesOpportunityResponseDto> getSalesOpportunityById(Long id);

    /**
     * Updates an existing sales opportunity.
     * @param id The ID of the sales opportunity to update.
     * @param updatedOpportunityDTO The DTO containing the updated data.
     * @return An Optional containing the DTO of the updated sales opportunity if found and updated, otherwise empty.
     */
    Optional<SalesOpportunityResponseDto> updateSalesOpportunity(Long id, SalesOpportunityDto updatedOpportunityDTO);

    /**
     * Deletes a sales opportunity by its ID.
     * @param id The ID of the sales opportunity to delete.
     */
    void deleteSalesOpportunity(Long id);

    // Placeholder methods (you might want to define more specific DTOs for these)
    void trackSalesActivity(Long opportunityId, String activityDetails);
    void sendReminder(Long opportunityId, String message);
}