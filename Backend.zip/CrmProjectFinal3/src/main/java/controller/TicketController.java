////package controller; // Adjust package name if different
////
////import payload.TicketDto;
////import service.TicketService;
////import org.springframework.http.HttpStatus;
////import org.springframework.http.ResponseEntity;
////import org.springframework.web.bind.annotation.*;
////import jakarta.validation.Valid;
////import reactor.core.publisher.Flux; // Import Flux for streaming multiple items
////import reactor.core.publisher.Mono; // Import Mono for single item or completion
////
////import java.util.List;
////
////@RestController
////@RequestMapping("/api")
////public class TicketController {
////
////    private final TicketService ticketService;
////
////    public TicketController(TicketService ticketService) {
////        this.ticketService = ticketService;
////    }
////
////    @PostMapping("/customers/{customerId}/products/{productId}/tickets")
////    public Mono<ResponseEntity<TicketDto>> createTicket(@PathVariable(value = "customerId") Long customerId,
////                                                        @PathVariable(value = "productId") Long productId,
////                                                        @Valid @RequestBody TicketDto ticketDto) {
////        return ticketService.createTicket(customerId, productId, ticketDto)
////                .map(createdTicket -> new ResponseEntity<>(createdTicket, HttpStatus.CREATED))
////                .onErrorResume(e -> { // Generic error handling for creation
////                    System.err.println("Error creating ticket: " + e.getMessage());
////                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
////                });
////    }
////
////    @GetMapping("/tickets/{ticketId}")
////    public Mono<ResponseEntity<TicketDto>> getTicketById(@PathVariable(name = "ticketId") Long ticketId) {
////        return ticketService.getTicketById(ticketId)
////                .map(ticketDto -> new ResponseEntity<>(ticketDto, HttpStatus.OK))
////                .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND)) // Handle case where Mono is empty (e.g., resource not found)
////                .onErrorResume(e -> {
////                    System.err.println("Error getting ticket by ID " + ticketId + ": " + e.getMessage());
////                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
////                });
////    }
////
////    @GetMapping("/customers/{customerId}/tickets")
////    public Flux<TicketDto> getTicketsByCustomerId(@PathVariable(name = "customerId") Long customerId) {
////        // Returns a Flux directly for streaming a list of tickets
////        return ticketService.getTicketsByCustomerId(customerId)
////                .doOnError(e -> System.err.println("Error getting tickets by customer ID " + customerId + ": " + e.getMessage()));
////                // No ResponseEntity wrapper here if you want direct Flux streaming
////    }
////
////    @GetMapping("/agents/{agentId}/tickets")
////    public Flux<TicketDto> getTicketsByAgentId(@PathVariable(name = "agentId") Long agentId) {
////        // Returns a Flux directly for streaming a list of tickets
////        return ticketService.getTicketsByAgentId(agentId)
////                .doOnError(e -> System.err.println("Error getting tickets by agent ID " + agentId + ": " + e.getMessage()));
////    }
////
////    @PutMapping("/tickets/{ticketId}/status")
////    public Mono<ResponseEntity<TicketDto>> updateTicketStatus(@PathVariable(name = "ticketId") Long ticketId,
////                                                              @RequestParam(name = "newStatus") String newStatus) {
////        return ticketService.updateTicketStatus(ticketId, newStatus)
////                .map(updatedTicket -> new ResponseEntity<>(updatedTicket, HttpStatus.OK))
////                .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND))
////                .onErrorResume(e -> {
////                    System.err.println("Error updating ticket status for ID " + ticketId + ": " + e.getMessage());
////                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
////                });
////    }
////
////    @PutMapping("/tickets/{ticketId}/assign-agent/{agentId}")
////    public Mono<ResponseEntity<TicketDto>> assignAgentToTicket(@PathVariable(name = "ticketId") Long ticketId,
////                                                               @PathVariable(name = "agentId") Long agentId) {
////        return ticketService.assignAgentToTicket(ticketId, agentId)
////                .map(updatedTicket -> new ResponseEntity<>(updatedTicket, HttpStatus.OK))
////                .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND))
////                .onErrorResume(e -> {
////                    System.err.println("Error assigning agent to ticket ID " + ticketId + ": " + e.getMessage());
////                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
////                });
////    }
////
////    @DeleteMapping("/tickets/{ticketId}")
////    public Mono<ResponseEntity<String>> deleteTicket(@PathVariable(name = "ticketId") Long ticketId) {
////        return ticketService.deleteTicket(ticketId)
////                .thenReturn(new ResponseEntity<>("Ticket deleted successfully.", HttpStatus.OK))
////                .onErrorResume(e -> {
////                    System.err.println("Error deleting ticket with ID " + ticketId + ": " + e.getMessage());
////                    return Mono.just(new ResponseEntity<>("Failed to delete ticket: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR));
////                })
////                .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND)); // In case deleteTicket returns empty mono before error
////    }
////
////    @GetMapping("/customers/{customerId}/ticket-count")
////    public Mono<ResponseEntity<Long>> getTicketCountByCustomerId(@PathVariable(name = "customerId") Long customerId) {
////        return ticketService.countTicketsByCustomerId(customerId)
////                .map(count -> new ResponseEntity<>(count, HttpStatus.OK))
////                .defaultIfEmpty(new ResponseEntity<>(0L, HttpStatus.OK)) // Default to 0 if no count found (though count methods usually return 0)
////                .onErrorResume(e -> {
////                    System.err.println("Error getting ticket count for customer ID " + customerId + ": " + e.getMessage());
////                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
////                });
////    }
////}
//package controller; // Adjust package name if different
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//import exception.ResourceNotFoundException;
//import jakarta.validation.Valid;
//import payload.TicketDto;
//import reactor.core.publisher.Flux; // Import Flux for streaming multiple items
//import reactor.core.publisher.Mono; // Import Mono for single item or completion
//import service.TicketService;
//
//@RestController
//@RequestMapping("/api")
//public class TicketController {
//
//    private final TicketService ticketService;
//
//    public TicketController(TicketService ticketService) {
//        this.ticketService = ticketService;
//    }
//
//    @PostMapping("/customers/{customerId}/products/{productId}/tickets")
//    public Mono<ResponseEntity<TicketDto>> createTicket(@PathVariable(value = "customerId") Long customerId,
//                                                        @PathVariable(value = "productId") Long productId,
//                                                        @Valid @RequestBody TicketDto ticketDto) {
//        return ticketService.createTicket(customerId, productId, ticketDto)
//                .map(createdTicket -> new ResponseEntity<>(createdTicket, HttpStatus.CREATED))
//                .onErrorResume(e -> { // Generic error handling for creation
//                    System.err.println("Error creating ticket: " + e.getMessage());
//                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
//                });
//    }
//
//    @GetMapping("/tickets/{ticketId}")
//    public Mono<ResponseEntity<TicketDto>> getTicketById(@PathVariable(name = "ticketId") Long ticketId) {
//        return ticketService.getTicketById(ticketId)
//                .map(ticketDto -> new ResponseEntity<>(ticketDto, HttpStatus.OK))
//                .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND)) // Handle case where Mono is empty (e.g., resource not found)
//                .onErrorResume(e -> {
//                    System.err.println("Error getting ticket by ID " + ticketId + ": " + e.getMessage());
//                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
//                });
//    }
//
//    @GetMapping("/customers/{customerId}/tickets")
//    public Flux<TicketDto> getTicketsByCustomerId(@PathVariable(name = "customerId") Long customerId) {
//        // Returns a Flux directly for streaming a list of tickets
//        return ticketService.getTicketsByCustomerId(customerId)
//                .doOnError(e -> System.err.println("Error getting tickets by customer ID " + customerId + ": " + e.getMessage()));
//                // No ResponseEntity wrapper here if you want direct Flux streaming
//    }
//
//    @GetMapping("/agents/{agentId}/tickets")
//    public Flux<TicketDto> getTicketsByAgentId(@PathVariable(name = "agentId") Long agentId) {
//        // Returns a Flux directly for streaming a list of tickets
//        return ticketService.getTicketsByAgentId(agentId)
//                .doOnError(e -> System.err.println("Error getting tickets by agent ID " + agentId + ": " + e.getMessage()));
//    }
//
//    @PutMapping("/tickets/{ticketId}/status")
//    public Mono<ResponseEntity<TicketDto>> updateTicketStatus(@PathVariable(name = "ticketId") Long ticketId,
//                                                              @RequestParam(name = "newStatus") String newStatus) {
//        return ticketService.updateTicketStatus(ticketId, newStatus)
//                .map(updatedTicket -> new ResponseEntity<>(updatedTicket, HttpStatus.OK))
//                .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND))
//                .onErrorResume(e -> {
//                    System.err.println("Error updating ticket status for ID " + ticketId + ": " + e.getMessage());
//                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
//                });
//    }
//
//    @PutMapping("/tickets/{ticketId}/assign-agent/{agentId}")
//    public Mono<ResponseEntity<TicketDto>> assignAgentToTicket(@PathVariable(name = "ticketId") Long ticketId,
//                                                               @PathVariable(name = "agentId") Long agentId) {
//        return ticketService.assignAgentToTicket(ticketId, agentId)
//                .map(updatedTicket -> new ResponseEntity<>(updatedTicket, HttpStatus.OK))
//                .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND))
//                .onErrorResume(e -> {
//                    System.err.println("Error assigning agent to ticket ID " + ticketId + ": " + e.getMessage());
//                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
//                });
//    }
//
//    @DeleteMapping("/tickets/{ticketId}")
//    public Mono<ResponseEntity<String>> deleteTicket(@PathVariable(name = "ticketId") Long ticketId) {
//        return ticketService.deleteTicket(ticketId)
//                .thenReturn(new ResponseEntity<>("Ticket deleted successfully.", HttpStatus.OK))
//                .onErrorResume(e -> {
//                    System.err.println("Error deleting ticket with ID " + ticketId + ": " + e.getMessage());
//                    return Mono.just(new ResponseEntity<>("Failed to delete ticket: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR));
//                })
//                .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND)); // In case deleteTicket returns empty mono before error
//    }
//
//    @GetMapping("/customers/{customerId}/ticket-count")
//    public Mono<ResponseEntity<Long>> getTicketCountByCustomerId(@PathVariable(name = "customerId") Long customerId) {
//        return ticketService.countTicketsByCustomerId(customerId)
//                .map(count -> new ResponseEntity<>(count, HttpStatus.OK))
//                .onErrorResume(ResourceNotFoundException.class, ex -> {
//                    // Specifically handle ResourceNotFoundException for customer not found
//                    return Mono.just(new ResponseEntity<>(HttpStatus.NOT_FOUND));
//                })
//                .onErrorResume(e -> {
//                    System.err.println("Error getting ticket count for customer ID " + customerId + ": " + e.getMessage());
//                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
//                });
//    }
//}
package controller; // Adjust package name if different

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import exception.ResourceNotFoundException;
import jakarta.validation.Valid;
import payload.TicketDto;
import reactor.core.publisher.Flux; // Import Flux for streaming multiple items
import reactor.core.publisher.Mono; // Import Mono for single item or completion
import service.TicketService;
@CrossOrigin
@RestController
@RequestMapping("/api")
public class TicketController {

    private final TicketService ticketService;

    public TicketController(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    @PostMapping("/customers/{customerId}/products/{productId}/tickets")
    public Mono<ResponseEntity<TicketDto>> createTicket(@PathVariable(value = "customerId") Long customerId,
                                                        @PathVariable(value = "productId") Long productId,
                                                        @Valid @RequestBody TicketDto ticketDto) {
        return ticketService.createTicket(customerId, productId, ticketDto)
                .map(createdTicket -> new ResponseEntity<>(createdTicket, HttpStatus.CREATED))
                .onErrorResume(e -> {
                    System.err.println("Error creating ticket: " + e.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }

    @GetMapping("/tickets/{ticketId}")
    public Mono<ResponseEntity<TicketDto>> getTicketById(@PathVariable(name = "ticketId") Long ticketId) {
        return ticketService.getTicketById(ticketId)
                .map(ticketDto -> new ResponseEntity<>(ticketDto, HttpStatus.OK))
                .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND))
                .onErrorResume(e -> {
                    System.err.println("Error getting ticket by ID " + ticketId + ": " + e.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }

    @GetMapping("/customers/{customerId}/tickets")
    public Flux<TicketDto> getTicketsByCustomerId(@PathVariable(name = "customerId") Long customerId) {
        return ticketService.getTicketsByCustomerId(customerId)
                .doOnError(e -> System.err.println("Error getting tickets by customer ID " + customerId + ": " + e.getMessage()));
    }

    @GetMapping("/agents/{agentId}/tickets")
    public Flux<TicketDto> getTicketsByAgentId(@PathVariable(name = "agentId") Long agentId) {
        return ticketService.getTicketsByAgentId(agentId)
                .doOnError(e -> System.err.println("Error getting tickets by agent ID " + agentId + ": " + e.getMessage()));
    }

    /**
     * Retrieves all tickets from the system.
     * GET /api/tickets
     *
     * @return A Flux emitting all TicketDto objects.
     */
    @GetMapping("/tickets")
    public Flux<TicketDto> getAllTickets() {
        return ticketService.getAllTickets()
                .doOnError(e -> System.err.println("Error getting all tickets: " + e.getMessage()));
    }


    @PutMapping("/tickets/{ticketId}/status")
    public Mono<ResponseEntity<TicketDto>> updateTicketStatus(@PathVariable(name = "ticketId") Long ticketId,
                                                                @RequestParam(name = "newStatus") String newStatus) {
        return ticketService.updateTicketStatus(ticketId, newStatus)
                .map(updatedTicket -> new ResponseEntity<>(updatedTicket, HttpStatus.OK))
                .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND))
                .onErrorResume(e -> {
                    System.err.println("Error updating ticket status for ID " + ticketId + ": " + e.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }

    @PutMapping("/tickets/{ticketId}/assign-agent/{agentId}")
    public Mono<ResponseEntity<TicketDto>> assignAgentToTicket(@PathVariable(name = "ticketId") Long ticketId,
                                                                 @PathVariable(name = "agentId") Long agentId) {
        return ticketService.assignAgentToTicket(ticketId, agentId)
                .map(updatedTicket -> new ResponseEntity<>(updatedTicket, HttpStatus.OK))
                .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND))
                .onErrorResume(e -> {
                    System.err.println("Error assigning agent to ticket ID " + ticketId + ": " + e.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }

    @DeleteMapping("/tickets/{ticketId}")
    public Mono<ResponseEntity<String>> deleteTicket(@PathVariable(name = "ticketId") Long ticketId) {
        return ticketService.deleteTicket(ticketId)
                .thenReturn(new ResponseEntity<>("Ticket deleted successfully.", HttpStatus.OK))
                .onErrorResume(e -> {
                    System.err.println("Error deleting ticket with ID " + ticketId + ": " + e.getMessage());
                    return Mono.just(new ResponseEntity<>("Failed to delete ticket: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR));
                })
                .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/customers/{customerId}/ticket-count")
    public Mono<ResponseEntity<Long>> getTicketCountByCustomerId(@PathVariable(name = "customerId") Long customerId) {
        return ticketService.countTicketsByCustomerId(customerId)
                .map(count -> new ResponseEntity<>(count, HttpStatus.OK))
                .onErrorResume(ResourceNotFoundException.class, ex -> {
                    return Mono.just(new ResponseEntity<>(HttpStatus.NOT_FOUND));
                })
                .onErrorResume(e -> {
                    System.err.println("Error getting ticket count for customer ID " + customerId + ": " + e.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }
}

