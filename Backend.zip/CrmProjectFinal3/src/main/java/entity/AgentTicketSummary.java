package entity;
 
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
 
@Entity
@Table(name = "agent_ticket_summaries") // This will be your new table name
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AgentTicketSummary {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
 
    // Agent ID to which this summary belongs.
    @Column(name = "agent_id", unique = true, nullable = false)
    private Long agentId;
 
    // Agent's name, stored directly in this summary table
    @Column(name = "agent_name", nullable = false)
    private String agentName;
 
    // REVERTED FIELD: Agent's email, stored directly in this summary table
    @Column(name = "agent_email", nullable = false)
    private String agentEmail;
 
    // The actual count of tickets assigned to this agent
    @Column(name = "ticket_count", nullable = false)
    private int ticketCount;
}
 