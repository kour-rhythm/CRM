package exception; // Adjust package name as per your actual project structure

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST) // Default status if not specified
public class CrmAPIException extends RuntimeException {

    private HttpStatus status;
    private String message;

    // Constructor to provide a custom HTTP status and message
    public CrmAPIException(HttpStatusCode httpStatusCode, String message) {
        super(message); // Call parent (RuntimeException) constructor with the message
        this.status = (HttpStatus) httpStatusCode;
        this.message = message;
    }

    // Constructor to provide just a message (will use the default @ResponseStatus)
    public CrmAPIException(String message) {
        super(message);
        this.status = HttpStatus.BAD_REQUEST; // Default to BAD_REQUEST if status not provided
        this.message = message;
    }

    public HttpStatus getStatus() {
        return status;
    }

    @Override // Override to ensure this message is returned by the exception
    public String getMessage() {
        return message;
    }
}