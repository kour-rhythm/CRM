package payload; // Adjust package name if different

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Email;

/**
 * Data Transfer Object (DTO) for Agent entity.
 * Used for exposing agent details via REST APIs.
 */
@Data // Generates getters, setters, toString, equals, hashCode
@NoArgsConstructor // Generates a no-argument constructor
@AllArgsConstructor // Generates a constructor with all fields
public class AgentDto {
    private Long id;

    @NotBlank(message = "Agent name cannot be empty")
    private String name;

    @NotBlank(message = "Agent email cannot be empty")
    @Email(message = "Agent email must be a valid email address")
    private String email;

    // This field will be populated from the derived count in the entity/service
    private int currentAssignedTicketsCount;
}
