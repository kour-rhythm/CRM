package payload;
 
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
 
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AgentTicketSummaryDto {
    private Long id;
    private String agentName;
    private Long agentId;
    private String agentEmail;
    private int ticketCount;
}