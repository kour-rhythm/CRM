// src/main/java/com/example/ticketing/payload/TicketDto.java
package payload; // Adjust package name

import entity.TicketStatus; // Adjust import
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TicketDto {
    private Long id;

    @NotBlank(message = "Issue description cannot be empty")
    @Size(min = 10, message = "Issue description must be at least 10 characters long")
    private String issue;

    private Long customerId; // Stays, as it's the ID
    private Long productId;  // Stays, as it's the ID

    private TicketStatus status;
    private Long assignedAgentId;
    private String assignedAgentName; // Stays, as Agent is local to this service
    private String createdAt;
    private String updatedAt;
}