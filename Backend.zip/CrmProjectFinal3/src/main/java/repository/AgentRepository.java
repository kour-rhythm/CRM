// src/main/java/com/example/ticketing/repository/AgentRepository.java
package repository; // Adjust package name

import entity.Agent; // Adjust import
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AgentRepository extends JpaRepository<Agent, Long> {
    Optional<Agent> findByName(String name);
    Optional<Agent> findByEmail(String email);
    List<Agent> findAll();
}