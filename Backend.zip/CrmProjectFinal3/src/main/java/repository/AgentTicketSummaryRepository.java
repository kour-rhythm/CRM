package repository;
 
import entity.AgentTicketSummary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
 
import java.util.Optional;
 
@Repository
public interface AgentTicketSummaryRepository extends JpaRepository<AgentTicketSummary, Long> {
    // Method to find the summary by agent ID
    Optional<AgentTicketSummary> findByAgentId(Long agentId);
}