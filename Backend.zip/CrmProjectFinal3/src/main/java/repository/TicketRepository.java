package repository; // Adjust package name if different

import entity.Ticket;
import entity.TicketStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TicketRepository extends JpaRepository<Ticket, Long> {
    List<Ticket> findByCustomerId(Long customerId);
    List<Ticket> findByProductId(Long productId);
    List<Ticket> findByAssignedAgentId(Long agentId);
    List<Ticket> findByStatus(TicketStatus status);
    Optional<Ticket> findByIdAndCustomerId(Long id, Long customerId);
    Optional<Ticket> findByIdAndAssignedAgentId(Long id, Long agentId);
    long countByCustomerId(Long customerId);
}
