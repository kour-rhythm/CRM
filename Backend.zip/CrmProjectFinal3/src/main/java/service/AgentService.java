package service; // Adjust package name if different

import payload.AgentDto;
import java.util.List;

/**
 * Service interface for Agent-related operations.
 * Defines methods for creating, retrieving, and managing agents.
 */
public interface AgentService {
    AgentDto createAgent(AgentDto agentDto);
    AgentDto getAgentById(Long agentId);
    List<AgentDto> getAllAgents();
    AgentDto updateAgent(Long agentId, AgentDto agentDto);
    void deleteAgent(Long agentId);
}
