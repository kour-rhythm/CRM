package service;
 
import payload.AgentTicketSummaryDto;
import java.util.List;
 
public interface AgentTicketSummaryService {
    List<AgentTicketSummaryDto> getAllAgentTicketSummaries();
    AgentTicketSummaryDto getAgentTicketSummaryByAgentId(Long agentId);
}