package service;

import payload.TicketDto;
import reactor.core.publisher.Flux; // Import Flux for reactive streams
import reactor.core.publisher.Mono; // Import Mono for reactive single values

import java.util.List;

public interface TicketService {

    Mono<TicketDto> createTicket(Long customerId, Long productId, TicketDto ticketDto);
    Mono<TicketDto> getTicketById(Long ticketId);
    Flux<TicketDto> getTicketsByCustomerId(Long customerId);
    Flux<TicketDto> getTicketsByAgentId(Long agentId);
    Flux<TicketDto> getAllTickets(); // New method to get all tickets
    Mono<TicketDto> updateTicketStatus(Long ticketId, String newStatus);
    Mono<TicketDto> assignAgentToTicket(Long ticketId, Long agentId);
    Mono<Void> deleteTicket(Long ticketId);
    Mono<Long> countTicketsByCustomerId(Long customerId);
}
