package service.impl; // Adjust package name if different

import entity.Agent;
import exception.ResourceNotFoundException;
import payload.AgentDto;
import repository.AgentRepository;
import service.AgentService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Implementation of the AgentService interface.
 * Handles the business logic for managing Agent entities.
 */
@Service
public class AgentServiceImpl implements AgentService {

    private final AgentRepository agentRepository;
    private final ModelMapper mapper;

    public AgentServiceImpl(AgentRepository agentRepository, ModelMapper mapper) {
        this.agentRepository = agentRepository;
        this.mapper = mapper;
    }

    @Override
    public AgentDto createAgent(AgentDto agentDto) {
        Agent agent = mapToEntity(agentDto);
        Agent newAgent = agentRepository.save(agent);
        return mapToDTO(newAgent);
    }

    @Override
    public AgentDto getAgentById(Long agentId) {
        Agent agent = agentRepository.findById(agentId)
                .orElseThrow(() -> new ResourceNotFoundException("Agent", "id", agentId));
        return mapToDTO(agent);
    }

    @Override
    public List<AgentDto> getAllAgents() {
        List<Agent> agents = agentRepository.findAll();
        return agents.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public AgentDto updateAgent(Long agentId, AgentDto agentDto) {
        Agent agent = agentRepository.findById(agentId)
                .orElseThrow(() -> new ResourceNotFoundException("Agent", "id", agentId));

        agent.setName(agentDto.getName());
        agent.setEmail(agentDto.getEmail());
        // Do NOT update currentAssignedTicketsCount directly from DTO here,
        // as it's derived or managed internally based on assigned tickets.

        Agent updatedAgent = agentRepository.save(agent);
        return mapToDTO(updatedAgent);
    }

    @Override
    public void deleteAgent(Long agentId) {
        Agent agent = agentRepository.findById(agentId)
                .orElseThrow(() -> new ResourceNotFoundException("Agent", "id", agentId));
        agentRepository.delete(agent);
    }

    // Helper method to map Entity to DTO
    private AgentDto mapToDTO(Agent agent) {
        AgentDto agentDto = mapper.map(agent, AgentDto.class);
        // Explicitly set the derived count
        agentDto.setCurrentAssignedTicketsCount(agent.getCurrentAssignedTicketsCount());
        return agentDto;
    }

    // Helper method to map DTO to Entity
    private Agent mapToEntity(AgentDto agentDto) {
        Agent agent = mapper.map(agentDto, Agent.class);
        // When mapping DTO to Entity for creation/update, do not set derived count from DTO
        return agent;
    }
}
