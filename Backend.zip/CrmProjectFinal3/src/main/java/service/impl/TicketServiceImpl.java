////package service.impl; // Adjust package name if different
////
////import entity.Agent;
////import entity.Ticket;
////import entity.TicketStatus;
////import exception.CrmAPIException;
////import exception.ResourceNotFoundException;
////import payload.TicketDto;
////import repository.AgentRepository;
////import repository.TicketRepository;
////import service.TicketService;
////
////import org.modelmapper.ModelMapper;
////import org.springframework.http.HttpStatus;
////import org.springframework.stereotype.Service;
////import org.springframework.transaction.annotation.Transactional;
////import org.springframework.web.reactive.function.client.WebClient;
////import reactor.core.publisher.Mono;
////import reactor.core.scheduler.Schedulers;
////
////import java.time.LocalDateTime;
////import java.time.format.DateTimeFormatter;
////import java.util.List;
////import java.util.Random;
////import java.util.stream.Collectors;
////
////@Service
////public class TicketServiceImpl implements TicketService {
////
////    // MAX_TICKETS_PER_AGENT is still a good concept for business logic
////    private static final int MAX_TICKETS_PER_AGENT = 5;
////
////    private final TicketRepository ticketRepository;
////    private final AgentRepository agentRepository;
////    private final ModelMapper mapper;
////    private final WebClient.Builder webClientBuilder;
////
////    private final Random random = new Random();
////
////    private static class ExternalProductDto {
////        private Long id;
////        private Long customerId;
////        public Long getId() { return id; }
////        public void setId(Long id) { this.id = id; }
////        public Long getCustomerId() { return customerId; }
////        public void setCustomerId(Long customerId) { this.customerId = customerId; }
////    }
////
////    public TicketServiceImpl(TicketRepository ticketRepository,
////                             AgentRepository agentRepository,
////                             ModelMapper mapper,
////                             WebClient.Builder webClientBuilder) {
////        this.ticketRepository = ticketRepository;
////        this.agentRepository = agentRepository;
////        this.mapper = mapper;
////        this.webClientBuilder = webClientBuilder;
////    }
////
////    @Override
////    @Transactional
////    public Mono<TicketDto> createTicket(Long customerId, Long productId, TicketDto ticketDto) {
////        WebClient customerProductWebClient = webClientBuilder.baseUrl("http://CustomerModule").build();
////
////        return customerProductWebClient.get()
////                .uri("/api/customers/{customerId}/products/{productId}", customerId, productId)
////                .retrieve()
////                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
////                    clientResponse.bodyToMono(String.class)
////                        .flatMap(errorBody -> {
////                            if (clientResponse.statusCode().equals(HttpStatus.NOT_FOUND)) {
////                                return Mono.error(new CrmAPIException(HttpStatus.BAD_REQUEST,
////                                        String.format("Product with ID '%d' is not associated with Customer with ID '%d' or does not exist.", productId, customerId)));
////                            } else {
////                                return Mono.error(new CrmAPIException(clientResponse.statusCode(), "Error from Customer-Product Service: " + errorBody));
////                            }
////                        })
////                )
////                .bodyToMono(ExternalProductDto.class)
////                .flatMap(validatedProduct -> {
////                    return Mono.fromCallable(() -> {
////                        Ticket ticket = mapper.map(ticketDto, Ticket.class);
////                        ticket.setCustomerId(customerId);
////                        ticket.setProductId(productId);
////                        ticket.setStatus(TicketStatus.OPEN);
////
////                        // Fetch available agents. The 'getCurrentAssignedTicketsCount()'
////                        // on the Agent entity will use the size of its 'assignedTickets' collection.
////                        List<Agent> availableAgents = agentRepository.findAll().stream()
////                                .filter(agent -> agent.getCurrentAssignedTicketsCount() < MAX_TICKETS_PER_AGENT)
////                                .collect(Collectors.toList());
////
////                        if (availableAgents.isEmpty()) {
////                            throw new CrmAPIException(HttpStatus.SERVICE_UNAVAILABLE, "No agents available to assign the ticket.");
////                        }
////
////                        Agent assignedAgent = availableAgents.get(random.nextInt(availableAgents.size()));
////                        ticket.setAssignedAgent(assignedAgent); // Set the assigned agent on the ticket
////
////                        // Saving the ticket will implicitly update the assignedTickets collection on the Agent
////                        // if the relationship is properly managed by JPA (which it is via @OneToMany on Agent).
////                        Ticket newTicket = ticketRepository.save(ticket);
////
////                        // If you need to immediately reflect the count in the Agent object *within this transaction*,
////                        // and assuming the Agent is still managed by the persistence context, you might need to
////                        // refresh the agent or explicitly load its tickets. However, for a derived @Transient field,
////                        // the size will reflect the database state after the ticket save.
////                        // The `getCurrentAssignedTicketsCount()` on the agent object will now correctly reflect
////                        // the updated count of assigned tickets because the new ticket has been associated.
////                        return mapToDTO(newTicket);
////                    }).subscribeOn(Schedulers.boundedElastic());
////                });
////    }
////
////    @Override
////    public TicketDto getTicketById(Long ticketId) {
////        Ticket ticket = ticketRepository.findById(ticketId)
////                .orElseThrow(() -> new ResourceNotFoundException("Ticket", "id", ticketId));
////        return mapToDTO(ticket);
////    }
////
////    @Override
////    public List<TicketDto> getTicketsByCustomerId(Long customerId) {
////        List<Ticket> tickets = ticketRepository.findByCustomerId(customerId);
////        return tickets.stream()
////                .map(this::mapToDTO)
////                .collect(Collectors.toList());
////    }
////
////    @Override
////    public List<TicketDto> getTicketsByAgentId(Long agentId) {
////        List<Ticket> tickets = ticketRepository.findByAssignedAgentId(agentId);
////        return tickets.stream()
////                .map(this::mapToDTO)
////                .collect(Collectors.toList());
////    }
////
////    @Override
////    @Transactional
////    public TicketDto updateTicketStatus(Long ticketId, String newStatus) {
////        Ticket ticket = ticketRepository.findById(ticketId)
////                .orElseThrow(() -> new ResourceNotFoundException("Ticket", "id", ticketId));
////
////        try {
////            ticket.setStatus(TicketStatus.valueOf(newStatus.toUpperCase()));
////        } catch (IllegalArgumentException e) {
////            throw new CrmAPIException(HttpStatus.BAD_REQUEST, "Invalid ticket status: " + newStatus);
////        }
////
////        Ticket updatedTicket = ticketRepository.save(ticket);
////        return mapToDTO(updatedTicket);
////    }
////
////    @Override
////    @Transactional
////    public TicketDto assignAgentToTicket(Long ticketId, Long agentId) {
////        Ticket ticket = ticketRepository.findById(ticketId)
////                .orElseThrow(() -> new ResourceNotFoundException("Ticket", "id", ticketId));
////
////        Agent agent = agentRepository.findById(agentId)
////                .orElseThrow(() -> new ResourceNotFoundException("Agent", "id", agentId));
////
////        // Check against the *derived* count
////        if (agent.getCurrentAssignedTicketsCount() >= MAX_TICKETS_PER_AGENT) {
////            throw new CrmAPIException(HttpStatus.BAD_REQUEST, "Agent " + agent.getName() + " has reached the maximum ticket limit.");
////        }
////
////        // CORRECTED: Remove the line that attempts to set a transient property directly.
////        // agent.setCurrentAssignedTicketsCount(agent.getCurrentAssignedTicketsCount() + 1);
////        // The count is derived from the collection.
////        // When the ticket is saved with the new agent, the relationship is managed by JPA.
////        // If you need the *agent's* count to be explicitly incremented and stored (not derived),
////        // then `currentAssignedTicketsCount` should be a regular `@Column` field, not `@Transient`.
////        // However, based on your `Agent.java`, it's designed to be derived.
////        // So, we just save the ticket, and the count will reflect correctly upon subsequent fetch.
////
////        ticket.setAssignedAgent(agent);
////        // Important: When you set the agent on the ticket and save the ticket,
////        // JPA updates the relationship. If 'assignedTickets' on Agent is EAGER,
////        // the collection will be hydrated upon fetching the Agent, and its size will be accurate.
////        Ticket updatedTicket = ticketRepository.save(ticket);
////
////        // To ensure the agent's ticket count is immediately updated in the database for *future* checks,
////        // and if 'currentAssignedTicketsCount' was a persistent field (not transient), you would
////        // explicitly increment and save the agent here.
////        // However, for a @Transient field, this explicit increment is unnecessary and incorrect.
////        // The count is derived from the tickets associated.
////        return mapToDTO(updatedTicket);
////    }
////
////    @Override
////    public void deleteTicket(Long ticketId) {
////        Ticket ticket = ticketRepository.findById(ticketId)
////                .orElseThrow(() -> new ResourceNotFoundException("Ticket", "id", ticketId));
////        ticketRepository.delete(ticket);
////    }
////
////    @Override
////    public long countTicketsByCustomerId(Long customerId) {
////        return ticketRepository.countByCustomerId(customerId);
////    }
////
////    // Helper method to map Entity to DTO
////    private TicketDto mapToDTO(Ticket ticket) {
////        TicketDto ticketDto = mapper.map(ticket, TicketDto.class);
////        ticketDto.setIssue(ticket.getIssue());
////        ticketDto.setCustomerId(ticket.getCustomerId());
////        ticketDto.setProductId(ticket.getProductId());
////        ticketDto.setStatus(ticket.getStatus());
////        if (ticket.getAssignedAgent() != null) {
////            ticketDto.setAssignedAgentId(ticket.getAssignedAgent().getId());
////            ticketDto.setAssignedAgentName(ticket.getAssignedAgent().getName());
////        }
////        if (ticket.getCreatedAt() != null) {
////            ticketDto.setCreatedAt(ticket.getCreatedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
////        }
////        if (ticket.getUpdatedAt() != null) {
////            ticketDto.setUpdatedAt(ticket.getUpdatedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
////        }
////        return ticketDto;
////    }
////
////    // Helper method to map DTO to Entity
////    private Ticket mapToEntity(TicketDto ticketDto) {
////        Ticket ticket = mapper.map(ticketDto, Ticket.class);
////        return ticket;
////    }
////}
//package service.impl;
//
//import entity.Agent;
//import entity.Ticket;
//import entity.TicketStatus;
//import exception.CrmAPIException;
//import exception.ResourceNotFoundException;
//// Ensure payload.CustomerBehaviorDetailDto is imported or defined as an inner class if needed
//import payload.TicketDto;
//import repository.AgentRepository;
//import repository.TicketRepository;
//import service.TicketService;
//
//import org.modelmapper.ModelMapper;
//import org.springframework.http.HttpStatus;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//import org.springframework.web.reactive.function.client.WebClient;
//import reactor.core.publisher.Flux; // Used for lists that could be streamed
//import reactor.core.publisher.Mono;
//import reactor.core.scheduler.Schedulers;
//
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;
//import java.util.List;
//import java.util.Random;
//import java.util.stream.Collectors;
//
//@Service
//public class TicketServiceImpl implements TicketService {
//
//    private static final int MAX_TICKETS_PER_AGENT = 5;
//
//    private final TicketRepository ticketRepository;
//    private final AgentRepository agentRepository;
//    private final ModelMapper mapper;
//    private final WebClient.Builder webClientBuilder; // Keep builder to create instances
//
//    private final Random random = new Random(); // Used for random agent assignment
//
//    // ExternalProductDto remains as an inner class as per your last request
//    private static class ExternalProductDto {
//        private Long id;
//        private Long customerId;
//        public Long getId() { return id; }
//        public void setId(Long id) { this.id = id; }
//        public Long getCustomerId() { return customerId; }
//        public void setCustomerId(Long customerId) { this.customerId = customerId; }
//    }
//
//    // NEW: Inner class to map response from CustomerModule's behavior-details endpoint for existence check
//    // This is similar to CustomerBehaviorDetailDto from ReportGeneration, but simplified for just ID.
//    // If you already have CustomerBehaviorDetailDto in this project's payload, you can use that instead.
//    // Assuming you have a simplified DTO for just fetching customer existence.
//    private static class CustomerExistenceDto {
//        private Long customerId;
//        // You might have other fields, but for existence check, just customerId or any field is enough
//        public Long getCustomerId() { return customerId; }
//        public void setCustomerId(Long customerId) { this.customerId = customerId; }
//    }
//
//
//    public TicketServiceImpl(TicketRepository ticketRepository,
//                             AgentRepository agentRepository,
//                             ModelMapper mapper,
//                             WebClient.Builder webClientBuilder) {
//        this.ticketRepository = ticketRepository;
//        this.agentRepository = agentRepository;
//        this.mapper = mapper;
//        this.webClientBuilder = webClientBuilder;
//    }
//
//    @Override
//    @Transactional
//    public Mono<TicketDto> createTicket(Long customerId, Long productId, TicketDto ticketDto) {
//        WebClient customerProductWebClient = webClientBuilder.baseUrl("http://CustomerModule").build();
//
//        return customerProductWebClient.get()
//                .uri("/api/customers/{customerId}/products/{productId}", customerId, productId)
//                .retrieve()
//                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
//                    clientResponse.bodyToMono(String.class)
//                        .flatMap(errorBody -> {
//                            if (clientResponse.statusCode().equals(HttpStatus.NOT_FOUND)) {
//                                return Mono.error(new CrmAPIException(HttpStatus.BAD_REQUEST,
//                                        String.format("Product with ID '%d' is not associated with Customer with ID '%d' or does not exist.", productId, customerId)));
//                            } else {
//                                return Mono.error(new CrmAPIException(clientResponse.statusCode(), "Error from Customer-Product Service: " + errorBody));
//                            }
//                        })
//                )
//                .bodyToMono(ExternalProductDto.class)
//                .flatMap(validatedProduct -> {
//                    return Mono.fromCallable(() -> {
//                        Ticket ticket = mapper.map(ticketDto, Ticket.class);
//                        ticket.setCustomerId(customerId);
//                        ticket.setProductId(productId);
//                        ticket.setStatus(TicketStatus.OPEN);
//
//                        List<Agent> availableAgents = agentRepository.findAll().stream()
//                                .filter(agent -> agent.getCurrentAssignedTicketsCount() < MAX_TICKETS_PER_AGENT)
//                                .collect(Collectors.toList());
//
//                        if (availableAgents.isEmpty()) {
//                            throw new CrmAPIException(HttpStatus.SERVICE_UNAVAILABLE, "No agents available to assign the ticket.");
//                        }
//
//                        Agent assignedAgent = availableAgents.get(random.nextInt(availableAgents.size()));
//                        ticket.setAssignedAgent(assignedAgent);
//
//                        Ticket newTicket = ticketRepository.save(ticket);
//                        return mapToDTO(newTicket);
//                    }).subscribeOn(Schedulers.boundedElastic());
//                });
//    }
//
//    @Override
//    public Mono<TicketDto> getTicketById(Long ticketId) {
//        return Mono.fromCallable(() -> {
//            Ticket ticket = ticketRepository.findById(ticketId)
//                    .orElseThrow(() -> new ResourceNotFoundException("Ticket", "id", ticketId));
//            return mapToDTO(ticket);
//        }).subscribeOn(Schedulers.boundedElastic());
//    }
//
//    @Override
//    public Flux<TicketDto> getTicketsByCustomerId(Long customerId) {
//        return Mono.fromCallable(() -> ticketRepository.findByCustomerId(customerId))
//                .subscribeOn(Schedulers.boundedElastic())
//                .flatMapMany(Flux::fromIterable)
//                .map(this::mapToDTO);
//    }
//
//    @Override
//    public Flux<TicketDto> getTicketsByAgentId(Long agentId) {
//        return Mono.fromCallable(() -> ticketRepository.findByAssignedAgentId(agentId))
//                .subscribeOn(Schedulers.boundedElastic())
//                .flatMapMany(Flux::fromIterable)
//                .map(this::mapToDTO);
//    }
//
//    @Override
//    @Transactional
//    public Mono<TicketDto> updateTicketStatus(Long ticketId, String newStatus) {
//        return Mono.fromCallable(() -> {
//            Ticket ticket = ticketRepository.findById(ticketId)
//                    .orElseThrow(() -> new ResourceNotFoundException("Ticket", "id", ticketId));
//
//            try {
//                ticket.setStatus(TicketStatus.valueOf(newStatus.toUpperCase()));
//            } catch (IllegalArgumentException e) {
//                throw new CrmAPIException(HttpStatus.BAD_REQUEST, "Invalid ticket status: " + newStatus);
//            }
//
//            Ticket updatedTicket = ticketRepository.save(ticket);
//            return mapToDTO(updatedTicket);
//        }).subscribeOn(Schedulers.boundedElastic());
//    }
//
//    @Override
//    @Transactional
//    public Mono<TicketDto> assignAgentToTicket(Long ticketId, Long agentId) {
//        return Mono.fromCallable(() -> {
//            Ticket ticket = ticketRepository.findById(ticketId)
//                    .orElseThrow(() -> new ResourceNotFoundException("Ticket", "id", ticketId));
//
//            Agent agent = agentRepository.findById(agentId)
//                    .orElseThrow(() -> new ResourceNotFoundException("Agent", "id", agentId));
//
//            if (agent.getCurrentAssignedTicketsCount() >= MAX_TICKETS_PER_AGENT) {
//                throw new CrmAPIException(HttpStatus.BAD_REQUEST, "Agent " + agent.getName() + " has reached the maximum ticket limit.");
//            }
//
//            ticket.setAssignedAgent(agent);
//            Ticket updatedTicket = ticketRepository.save(ticket);
//            return mapToDTO(updatedTicket);
//        }).subscribeOn(Schedulers.boundedElastic());
//    }
//
//    @Override
//    @Transactional
//    public Mono<Void> deleteTicket(Long ticketId) {
//        return Mono.fromRunnable(() -> {
//            Ticket ticket = ticketRepository.findById(ticketId)
//                    .orElseThrow(() -> new ResourceNotFoundException("Ticket", "id", ticketId));
//            ticketRepository.delete(ticket);
//        }).subscribeOn(Schedulers.boundedElastic()).then();
//    }
//
//    @Override
//    public Mono<Long> countTicketsByCustomerId(Long customerId) {
//        WebClient customerModuleWebClient = webClientBuilder.baseUrl("http://CustomerModule").build();
//
//        // Step 1: Verify customer existence using CustomerModule's API
//        return customerModuleWebClient.get()
//                .uri("/api/customers/{customerId}/behavior-details", customerId) // Use an existing endpoint that confirms customer existence
//                .retrieve()
//                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
//                    clientResponse.bodyToMono(String.class)
//                        .flatMap(errorBody -> {
//                            if (clientResponse.statusCode().equals(HttpStatus.NOT_FOUND)) {
//                                // If customer not found in CustomerModule, throw ResourceNotFoundException
//                                return Mono.error(new ResourceNotFoundException("Customer", "id", customerId));
//                            } else {
//                                // For other errors from CustomerModule, wrap in CrmAPIException
//                                return Mono.error(new CrmAPIException(clientResponse.statusCode(),
//                                        "Error from Customer Module during existence check: " + errorBody));
//                            }
//                        })
//                )
//                .bodyToMono(CustomerExistenceDto.class) // Just need to know if it successfully returned *any* customer data
//                .flatMap(customerExistence -> {
//                    // Step 2: If customer exists, then proceed to count tickets (blocking JPA call)
//                    return Mono.fromCallable(() -> ticketRepository.countByCustomerId(customerId))
//                            .subscribeOn(Schedulers.boundedElastic()); // Offload blocking operation
//                });
//    }
//
//    // Helper method to map Entity to DTO
//    private TicketDto mapToDTO(Ticket ticket) {
//        TicketDto ticketDto = mapper.map(ticket, TicketDto.class);
//        ticketDto.setIssue(ticket.getIssue());
//        ticketDto.setCustomerId(ticket.getCustomerId());
//        ticketDto.setProductId(ticket.getProductId());
//        ticketDto.setStatus(ticket.getStatus());
//        if (ticket.getAssignedAgent() != null) {
//            ticketDto.setAssignedAgentId(ticket.getAssignedAgent().getId());
//            ticketDto.setAssignedAgentName(ticket.getAssignedAgent().getName());
//        }
//        if (ticket.getCreatedAt() != null) {
//            ticketDto.setCreatedAt(ticket.getCreatedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
//        }
//        if (ticket.getUpdatedAt() != null) {
//            ticketDto.setUpdatedAt(ticket.getUpdatedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
//        }
//        return ticketDto;
//    }
//
//    // Helper method to map DTO to Entity
//    private Ticket mapToEntity(TicketDto ticketDto) {
//        return mapper.map(ticketDto, Ticket.class);
//    }
//}
package service.impl;

import entity.Agent;
import entity.Ticket;
import entity.TicketStatus;
import exception.CrmAPIException;
import exception.ResourceNotFoundException;
import payload.TicketDto;
import repository.AgentRepository;
import repository.TicketRepository;
import service.TicketService;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Service
public class TicketServiceImpl implements TicketService {

    private static final int MAX_TICKETS_PER_AGENT = 5;

    private final TicketRepository ticketRepository;
    private final AgentRepository agentRepository;
    private final ModelMapper mapper;
    private final WebClient.Builder webClientBuilder;

    private final Random random = new Random();

    private static class ExternalProductDto {
        private Long id;
        private Long customerId;
        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public Long getCustomerId() { return customerId; }
        public void setCustomerId(Long customerId) { this.customerId = customerId; }
    }

    private static class CustomerExistenceDto {
        private Long customerId;
        public Long getCustomerId() { return customerId; }
        public void setCustomerId(Long customerId) { this.customerId = customerId; }
    }


    public TicketServiceImpl(TicketRepository ticketRepository,
                             AgentRepository agentRepository,
                             ModelMapper mapper,
                             WebClient.Builder webClientBuilder) {
        this.ticketRepository = ticketRepository;
        this.agentRepository = agentRepository;
        this.mapper = mapper;
        this.webClientBuilder = webClientBuilder;
    }

    @Override
    @Transactional
    public Mono<TicketDto> createTicket(Long customerId, Long productId, TicketDto ticketDto) {
        WebClient customerProductWebClient = webClientBuilder.baseUrl("http://CustomerModule").build();

        return customerProductWebClient.get()
                .uri("/api/customers/{customerId}/products/{productId}", customerId, productId)
                .retrieve()
                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
                    clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> {
                            if (clientResponse.statusCode().equals(HttpStatus.NOT_FOUND)) {
                                return Mono.error(new CrmAPIException(HttpStatus.BAD_REQUEST,
                                        String.format("Product with ID '%d' is not associated with Customer with ID '%d' or does not exist.", productId, customerId)));
                            } else {
                                return Mono.error(new CrmAPIException(clientResponse.statusCode(), "Error from Customer-Product Service: " + errorBody));
                            }
                        })
                )
                .bodyToMono(ExternalProductDto.class)
                .flatMap(validatedProduct -> {
                    return Mono.fromCallable(() -> {	
                        Ticket ticket = mapper.map(ticketDto, Ticket.class);
                        ticket.setCustomerId(customerId);
                        ticket.setProductId(productId);
                        ticket.setStatus(TicketStatus.OPEN);

                        List<Agent> availableAgents = agentRepository.findAll().stream()
                                .filter(agent -> agent.getCurrentAssignedTicketsCount() < MAX_TICKETS_PER_AGENT)
                                .collect(Collectors.toList());

                        if (availableAgents.isEmpty()) {
                            throw new CrmAPIException(HttpStatus.SERVICE_UNAVAILABLE, "No agents available to assign the ticket.");
                        }

                        Agent assignedAgent = availableAgents.get(random.nextInt(availableAgents.size()));
                        ticket.setAssignedAgent(assignedAgent);

                        Ticket newTicket = ticketRepository.save(ticket);
                        return mapToDTO(newTicket);
                    }).subscribeOn(Schedulers.boundedElastic());
                });
    }

    @Override
    public Mono<TicketDto> getTicketById(Long ticketId) {
        return Mono.fromCallable(() -> {
            Ticket ticket = ticketRepository.findById(ticketId)
                    .orElseThrow(() -> new ResourceNotFoundException("Ticket", "id", ticketId));
            return mapToDTO(ticket);
        }).subscribeOn(Schedulers.boundedElastic());
    }

    @Override
    public Flux<TicketDto> getTicketsByCustomerId(Long customerId) {
        return Mono.fromCallable(() -> ticketRepository.findByCustomerId(customerId))
                .subscribeOn(Schedulers.boundedElastic())
                .flatMapMany(Flux::fromIterable)
                .map(this::mapToDTO);
    }

    @Override
    public Flux<TicketDto> getTicketsByAgentId(Long agentId) {
        return Mono.fromCallable(() -> ticketRepository.findByAssignedAgentId(agentId))
                .subscribeOn(Schedulers.boundedElastic())
                .flatMapMany(Flux::fromIterable)
                .map(this::mapToDTO);
    }

    /**
     * Retrieves all tickets from the database.
     * This operation is offloaded to a bounded elastic scheduler for blocking JPA calls.
     *
     * @return A Flux emitting all TicketDto objects.
     */
    @Override
    public Flux<TicketDto> getAllTickets() {
        return Mono.fromCallable(() -> ticketRepository.findAll()) // Blocking call wrapped in Mono.fromCallable
                .subscribeOn(Schedulers.boundedElastic()) // Offload to a dedicated thread pool
                .flatMapMany(Flux::fromIterable) // Convert the List<Ticket> to Flux<Ticket>
                .map(this::mapToDTO); // Map each Ticket entity to a TicketDto
    }

    @Override
    @Transactional
    public Mono<TicketDto> updateTicketStatus(Long ticketId, String newStatus) {
        return Mono.fromCallable(() -> {
            Ticket ticket = ticketRepository.findById(ticketId)
                    .orElseThrow(() -> new ResourceNotFoundException("Ticket", "id", ticketId));

            try {
                ticket.setStatus(TicketStatus.valueOf(newStatus.toUpperCase()));
            } catch (IllegalArgumentException e) {
                throw new CrmAPIException(HttpStatus.BAD_REQUEST, "Invalid ticket status: " + newStatus);
            }

            Ticket updatedTicket = ticketRepository.save(ticket);
            return mapToDTO(updatedTicket);
        }).subscribeOn(Schedulers.boundedElastic());
    }

    @Override
    @Transactional
    public Mono<TicketDto> assignAgentToTicket(Long ticketId, Long agentId) {
        return Mono.fromCallable(() -> {
            Ticket ticket = ticketRepository.findById(ticketId)
                    .orElseThrow(() -> new ResourceNotFoundException("Ticket", "id", ticketId));

            Agent agent = agentRepository.findById(agentId)
                    .orElseThrow(() -> new ResourceNotFoundException("Agent", "id", agentId));

            if (agent.getCurrentAssignedTicketsCount() >= MAX_TICKETS_PER_AGENT) {
                throw new CrmAPIException(HttpStatus.BAD_REQUEST, "Agent " + agent.getName() + " has reached the maximum ticket limit.");
            }

            ticket.setAssignedAgent(agent);
            Ticket updatedTicket = ticketRepository.save(ticket);
            return mapToDTO(updatedTicket);
        }).subscribeOn(Schedulers.boundedElastic());
    }

    @Override
    @Transactional
    public Mono<Void> deleteTicket(Long ticketId) {
        return Mono.fromRunnable(() -> {
            Ticket ticket = ticketRepository.findById(ticketId)
                    .orElseThrow(() -> new ResourceNotFoundException("Ticket", "id", ticketId));
            ticketRepository.delete(ticket);
        }).subscribeOn(Schedulers.boundedElastic()).then();
    }

    @Override
    public Mono<Long> countTicketsByCustomerId(Long customerId) {
        WebClient customerModuleWebClient = webClientBuilder.baseUrl("http://CustomerModule").build();

        // Step 1: Verify customer existence using CustomerModule's API
        return customerModuleWebClient.get()
                .uri("/api/customers/{customerId}/behavior-details", customerId) // Use an existing endpoint that confirms customer existence
                .retrieve()
                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
                    clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> {
                            if (clientResponse.statusCode().equals(HttpStatus.NOT_FOUND)) {
                                // If customer not found in CustomerModule, throw ResourceNotFoundException
                                return Mono.error(new ResourceNotFoundException("Customer", "id", customerId));
                            } else {
                                // For other errors from CustomerModule, wrap in CrmAPIException
                                return Mono.error(new CrmAPIException(clientResponse.statusCode(),
                                        "Error from Customer Module during existence check: " + errorBody));
                            }
                        })
                )
                .bodyToMono(CustomerExistenceDto.class) // Just need to know if it successfully returned *any* customer data
                .flatMap(customerExistence -> {
                    // Step 2: If customer exists, then proceed to count tickets (blocking JPA call)
                    return Mono.fromCallable(() -> ticketRepository.countByCustomerId(customerId))
                            .subscribeOn(Schedulers.boundedElastic()); // Offload blocking operation
                });
    }

    // Helper method to map Entity to DTO
    private TicketDto mapToDTO(Ticket ticket) {
        TicketDto ticketDto = mapper.map(ticket, TicketDto.class);
        ticketDto.setIssue(ticket.getIssue());
        ticketDto.setCustomerId(ticket.getCustomerId());
        ticketDto.setProductId(ticket.getProductId());
        ticketDto.setStatus(ticket.getStatus());
        if (ticket.getAssignedAgent() != null) {
            ticketDto.setAssignedAgentId(ticket.getAssignedAgent().getId());
            ticketDto.setAssignedAgentName(ticket.getAssignedAgent().getName());
        }
        if (ticket.getCreatedAt() != null) {
            ticketDto.setCreatedAt(ticket.getCreatedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        }
        if (ticket.getUpdatedAt() != null) {
            ticketDto.setUpdatedAt(ticket.getUpdatedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        }
        return ticketDto;
    }

    // Helper method to map DTO to Entity
    private Ticket mapToEntity(TicketDto ticketDto) {
        return mapper.map(ticketDto, Ticket.class);
    }
}
