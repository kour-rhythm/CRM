package controller; // Adjust package name if different

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import payload.CustomerBehaviorDetailDto;
import payload.CustomerDto;
import payload.CustomerResponse;
import service.CustomerService;

@CrossOrigin
@RestController
@RequestMapping("api/customers")
public class CustomerController {
    private final CustomerService customerService;

    @Autowired
    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @PostMapping
    public ResponseEntity<CustomerDto> createCustomer(@Valid @RequestBody CustomerDto customerDto) {
        return new ResponseEntity<>(customerService.createCustomer(customerDto), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<CustomerResponse> getAllCustomers(
            @RequestParam(value = "pageNo", defaultValue = "0", required = false) int pageNo,
            @RequestParam(value = "pageSize", defaultValue = "5", required = false) int pageSize,
            @RequestParam(value = "sortBy", defaultValue = "noOfOrders", required = false) String sortBy,
            @RequestParam(value = "sortDir", defaultValue = "desc", required = false) String sortDir
    ) {
        CustomerResponse customerResponse = customerService.getAllCustomers(pageNo, pageSize, sortBy, sortDir);
        return new ResponseEntity<>(customerResponse, HttpStatus.OK);
    }

    @GetMapping("/by-ids")
    public ResponseEntity<List<CustomerDto>> getCustomersByIds(@RequestParam("ids") List<Long> customerIds) {
        List<CustomerDto> customers = customerService.getCustomersByIds(customerIds);
        return ResponseEntity.ok(customers);
    }

    @GetMapping("/{customerId}/behavior-details")
    public ResponseEntity<CustomerBehaviorDetailDto> getCustomerBehaviorDetails(@PathVariable Long customerId) {
        CustomerBehaviorDetailDto details = customerService.getCustomerBehaviorDetails(customerId);
        return ResponseEntity.ok(details);
    }
}
