package controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import payload.ProductDto;
import payload.ProductResponse;
import service.ProductService;
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
@RestController
@RequestMapping("/api")
public class ProductController {
    private ProductService productService;

    public ProductController(ProductService productService) {
        super();
        this.productService = productService;
    }

    @PostMapping("/customers/{customerId}/products")
    public ResponseEntity<ProductDto> createProduct(@PathVariable(value="customerId") long customerId,@Valid @RequestBody ProductDto productDto){
        return new ResponseEntity<>(productService.createProduct(customerId,productDto),HttpStatus.CREATED);
    }

    @GetMapping("/customers/{customerId}/products")
    public ResponseEntity<ProductResponse> getProductsByCustomerId(
            @PathVariable(value="customerId") Long customerId,
            @RequestParam(value = "pageNo", defaultValue = "0", required = false) int pageNo,
            @RequestParam(value = "pageSize", defaultValue = "5", required = false) int pageSize,
            @RequestParam(value = "sortBy", defaultValue = "id", required = false) String sortBy,
            @RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir
    ) {
        ProductResponse productResponse = productService.getProductsByCustomerId(customerId, pageNo, pageSize, sortBy, sortDir);
        return new ResponseEntity<>(productResponse, HttpStatus.OK);
    }
    @GetMapping("/products/{id}") // This will map to /api/products/{id}
    public ResponseEntity<ProductDto> getProductById(@PathVariable(value = "id") Long productId){
        ProductDto productDto = productService.getProductById(productId); // This calls the service
        return new ResponseEntity<>(productDto, HttpStatus.OK); // This attempts to return the DTO
    }

    @GetMapping("/customers/{customerId}/products/{id}")
    public ResponseEntity<ProductDto> getProductByCustomerId(@PathVariable(value = "customerId") Long customerId,
                                                           @PathVariable(value = "id") Long productId){
        ProductDto productDto = productService.getProductById(customerId, productId);
        return new ResponseEntity<>(productDto, HttpStatus.OK);
    }

    // MODIFIED ENDPOINT: Now includes pagination and sorting
    @GetMapping("/products")
    public ResponseEntity<ProductResponse> getAllProducts(
            @RequestParam(value = "pageNo", defaultValue = "0", required = false) int pageNo,
            @RequestParam(value = "pageSize", defaultValue = "10", required = false) int pageSize,
            @RequestParam(value = "sortBy", defaultValue = "id", required = false) String sortBy,
            @RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir
    ) {
        ProductResponse productResponse = productService.getAllProducts(pageNo, pageSize, sortBy, sortDir);
        return new ResponseEntity<>(productResponse, HttpStatus.OK);
    }
}