package entity; // Adjust package name if different

import java.time.LocalDateTime;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.PrePersist;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="product")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(nullable=false)
	private String productName;
	@Column(nullable=false)
	private String productBrandName;
	@Column(nullable=false)
	private String productBrandDescription;
	@Column(nullable=false)
	private int productPrice;
	@Column(nullable=false)
	private int productReviewOutOfFive;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "customer_id", nullable = false)
	private Customer customer;

	// FIX: Added columnDefinition to provide a default value for existing rows
    // This instructs Hibernate to generate DDL with a default for existing records.
	@Column(nullable = false, updatable = false, columnDefinition = "DATETIME(6) DEFAULT CURRENT_TIMESTAMP(6)")
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        // Ensure that createdAt is always set on new entities, even if the DB default fails for some reason
        if (this.createdAt == null) {
            this.createdAt = LocalDateTime.now();
        }
    }
}
