package payload; // Adjust package name if different

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerBehaviorDetailDto {
    private Long customerId;
    private String customerName;
    private String customerEmail;
    private int noOfOrders;
    private LocalDateTime mostRecentOrderDate;
}
