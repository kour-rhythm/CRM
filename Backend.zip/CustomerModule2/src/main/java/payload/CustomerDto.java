package payload;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDto {
	private Long id;
    @NotBlank(message = "Name cannot be empty")
    private String name;

    @NotBlank(message = "Mobile number cannot be empty")
    private String mobileNo;

    @NotBlank(message = "Email cannot be empty")
    private String emailId;

    @Min(value = 0, message = "Number of orders cannot be negative")
    private int noOfOrders;
}
