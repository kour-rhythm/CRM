package payload;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ProductDto {
    private Long id;

    @NotEmpty(message="Name should not be empty")
    private String productName;
    @NotEmpty(message="Brand name should not be empty")
    private String productBrandName;
    @NotEmpty(message="Product Description should not be empty")
    private String productBrandDescription;
    @NotNull(message="Price should not be empty") 
    private int productPrice;
    @NotNull(message="Review should not be empty")
    @Min(value = 1, message = "Product review must be at least 1")
    @Max(value = 5, message = "Product review cannot be more than 5")
    private int productReviewOutOfFive;

}