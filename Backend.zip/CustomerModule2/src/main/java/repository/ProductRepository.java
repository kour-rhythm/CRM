package repository;

import java.util.List; // Keep this if you still have other methods returning List
import org.springframework.data.domain.Page; // New import
import org.springframework.data.domain.Pageable; // New import
import org.springframework.data.jpa.repository.JpaRepository;

import entity.Product;

public interface ProductRepository extends JpaRepository<Product,Long> {
    Page<Product> findByCustomerId(long customerId, Pageable pageable);
}