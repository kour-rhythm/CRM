package service; // Adjust package name if different

import java.util.List;

import payload.CustomerBehaviorDetailDto;
import payload.CustomerDto;
import payload.CustomerResponse;

public interface CustomerService {

    CustomerDto createCustomer(CustomerDto customerDto);
    CustomerResponse getAllCustomers(int pageNo, int pageSize, String sortBy, String sortDir);
    List<CustomerDto> getCustomersByIds(List<Long> customerIds);
    CustomerBehaviorDetailDto getCustomerBehaviorDetails(Long customerId);
}
