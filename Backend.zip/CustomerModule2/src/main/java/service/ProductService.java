package service;

import java.util.List;

import payload.ProductDto;
import payload.ProductResponse;

public interface ProductService {
    ProductDto createProduct(long customerId, ProductDto productDto);

    ProductResponse getProductsByCustomerId(Long customerId, int pageNo, int pageSize, String sortBy, String sortDir);
    ProductDto getProductById(Long productId);
    ProductDto getProductById(Long customerId, Long productId);
    ProductResponse getAllProducts(int pageNo, int pageSize, String sortBy, String sortDir);
}