package service.impl;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import entity.User;
import exception.CrmAPIException;
import payload.LoginDto;
import payload.RegisterDto;
import repository.UserRepository;
import service.AuthService;

@Service
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;

    public AuthServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public String login(LoginDto loginDto) {
        User user = userRepository.findByUsernameOrEmail(loginDto.getUsernameOrEmail(), loginDto.getUsernameOrEmail())
                .orElseThrow(() -> new CrmAPIException(HttpStatus.BAD_REQUEST, "Invalid username or email"));

        if (!user.getPassword().equals(loginDto.getPassword())) {
            throw new CrmAPIException(HttpStatus.BAD_REQUEST, "Incorrect password");
        }

        return "Login successful!";
    }

    @Override
    public String register(RegisterDto registerDto) {
        // Check if username already exists
        if (userRepository.existsByUsername(registerDto.getUsername())) {
            throw new CrmAPIException(HttpStatus.BAD_REQUEST, "Username already exists!");
        }

        // Check if email already exists
        if (userRepository.existsByEmail(registerDto.getEmail())) {
            throw new CrmAPIException(HttpStatus.BAD_REQUEST, "Email already exists!");
        }

        // Create new user and save to database
        User user = new User();
        user.setName(registerDto.getName());
        user.setUsername(registerDto.getUsername());
        user.setEmail(registerDto.getEmail());
        user.setPassword(registerDto.getPassword()); // No encoding since security is removed

        userRepository.save(user);

        return "User registered successfully!";
    }
}
