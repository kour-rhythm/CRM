package service.impl; // Adjust package name if different

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import entity.Customer;
import entity.Product;
import exception.ResourceNotFoundException;
import payload.CustomerBehaviorDetailDto;
import payload.CustomerDto;
import payload.CustomerResponse;
import repository.CustomerRepository;
import service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {
    private final CustomerRepository customerRepository;
    private final ModelMapper mapper;

    @Autowired
    public CustomerServiceImpl(CustomerRepository customerRepository, ModelMapper mapper) {
        this.customerRepository = customerRepository;
        this.mapper = mapper;
    }

    @Override
    public CustomerDto createCustomer(CustomerDto customerDto) {
        if (customerDto.getEmailId() == null || customerDto.getEmailId().trim().isEmpty()) {
            throw new IllegalArgumentException("Email ID cannot be null or empty");
        }
        
        Customer customer = mapToEntity(customerDto);
        Customer newCustomer = customerRepository.save(customer);
        return mapToDTO(newCustomer);
    }

    @Override
    public List<CustomerDto> getCustomersByIds(List<Long> customerIds) {
        List<Customer> customers = customerRepository.findAllById(customerIds);
        return customers.stream()
                .map(customer -> mapper.map(customer, CustomerDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public CustomerResponse getAllCustomers(int pageNo, int pageSize, String sortBy, String sortDir) {
        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
        Page<Customer> customersPage = customerRepository.findAll(pageable);
        List<Customer> customers = customersPage.getContent();
        List<CustomerDto> content = customers.stream().map(this::mapToDTO).collect(Collectors.toList());

        CustomerResponse customerResponse = new CustomerResponse();
        customerResponse.setContent(content);
        customerResponse.setPageNo(customersPage.getNumber());
        customerResponse.setPageSize(customersPage.getSize());
        customerResponse.setTotalElements(customersPage.getTotalElements());
        customerResponse.setTotalPages(customersPage.getTotalPages());
        customerResponse.setLast(customersPage.isLast());

        return customerResponse;
    }

    @Override
    public CustomerBehaviorDetailDto getCustomerBehaviorDetails(Long customerId) {
        Customer customer = customerRepository.findById(customerId)
            .orElseThrow(() -> new ResourceNotFoundException("Customer", "id", customerId));

        LocalDateTime mostRecentOrderDate = customer.getProducts().stream()
            .map(Product::getCreatedAt)
            .max(LocalDateTime::compareTo)
            .orElse(null);

        return new CustomerBehaviorDetailDto(
            customer.getId(),
            customer.getName(),
            customer.getEmailId(),
            customer.getNoOfOrders(),
            mostRecentOrderDate
        );
    }

    private CustomerDto mapToDTO(Customer customer) {
        return mapper.map(customer, CustomerDto.class);
    }

    private Customer mapToEntity(CustomerDto customerDto) {
        return mapper.map(customerDto, Customer.class);
    }
}
