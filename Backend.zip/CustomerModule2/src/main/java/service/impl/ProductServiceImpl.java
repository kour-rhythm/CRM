package service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // Import for transactional annotation

import entity.Customer;
import entity.Product;
import exception.CrmAPIException;
import exception.ResourceNotFoundException;
import payload.ProductDto;
import payload.ProductResponse;
import repository.CustomerRepository;
import repository.ProductRepository;
import service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
    private final ProductRepository productRepository;
    private final CustomerRepository customerRepository;
    private final ModelMapper mapper;

    public ProductServiceImpl(ProductRepository productRepository, CustomerRepository customerRepository, ModelMapper mapper) {
        this.productRepository = productRepository;
        this.customerRepository = customerRepository;
        this.mapper = mapper;
    }

    @Override
    @Transactional // Ensure this method runs in a single transaction
    public ProductDto createProduct(long customerId, ProductDto productDto) {
        // Retrieve customer entity by id
        Customer customer = customerRepository.findById(customerId).orElseThrow(
                () -> new ResourceNotFoundException("Customer", "id", customerId));

        Product product = mapToEntity(productDto);
        // set customer to product entity
        product.setCustomer(customer);

        // product entity to DB
        Product newProduct = productRepository.save(product);

        // --- START: Code to update no_of_orders ---
        // Increment the no_of_orders for the associated customer
        customer.setNoOfOrders(customer.getNoOfOrders() + 1);
        // Save the updated customer entity
        customerRepository.save(customer);
        // --- END: Code to update no_of_orders ---

        return mapToDTO(newProduct);
    }
 // Inside ProductServiceImpl in CustomerModule
 // Inside ProductServiceImpl in CustomerModule
    @Override
    public ProductDto getProductById(Long productId) {
        // 1. Fetch the Product entity from the repository
        Product product = productRepository.findById(productId)
                                .orElse(null);

        // 2. Check if the product was found
        if (product == null) {
            return null; // If product not found, return null
        }

        // 3. Map the Product entity to a ProductDto
        return mapper.map(product, ProductDto.class); // This is where the mapping happens
    }
    @Override
    public ProductResponse getProductsByCustomerId(Long customerId, int pageNo, int pageSize, String sortBy, String sortDir) {
        // Retrieve customer entity by id to ensure existence
        customerRepository.findById(customerId).orElseThrow(
                () -> new ResourceNotFoundException("Customer", "id", customerId));

        // Create Sort object
        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        // Create Pageable instance
        Pageable pageable = PageRequest.of(pageNo, pageSize, sort);

        // Fetch paginated products for the given customer
        Page<Product> productsPage = productRepository.findByCustomerId(customerId, pageable);

        // Get content for page object
        List<Product> products = productsPage.getContent();

        // convert list of product entities to list of product DTOs
        List<ProductDto> content = products.stream().map(this::mapToDTO).collect(Collectors.toList());

        // Create ProductResponse object and populate it with data
        ProductResponse productResponse = new ProductResponse();
        productResponse.setContent(content);
        productResponse.setPageNo(productsPage.getNumber());
        productResponse.setPageSize(productsPage.getSize());
        productResponse.setTotalElements(productsPage.getTotalElements());
        productResponse.setTotalPages(productsPage.getTotalPages());
        productResponse.setLast(productsPage.isLast());

        return productResponse;
    }

    @Override
    public ProductDto getProductById(Long customerId, Long productId) {
        // retrieve customer entity by id
        Customer customer = customerRepository.findById(customerId).orElseThrow(
                () -> new ResourceNotFoundException("Customer", "id", customerId));

        // retrieve product by id
        Product product = productRepository.findById(productId).orElseThrow(() ->
                new ResourceNotFoundException("Product", "id", productId));

        if (product.getCustomer().getId() != customer.getId()) {
            throw new CrmAPIException(HttpStatus.BAD_REQUEST, "Product does not belong to customer");
        }

        return mapToDTO(product);
    }

    @Override
    public ProductResponse getAllProducts(int pageNo, int pageSize, String sortBy, String sortDir) {
        // Create Sort object
        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        // Create Pageable instance
        Pageable pageable = PageRequest.of(pageNo, pageSize, sort);

        // Fetch all products with pagination
        Page<Product> productsPage = productRepository.findAll(pageable); // Using findAll with Pageable

        // Get content for page object
        List<Product> products = productsPage.getContent();

        // Convert list of product entities to list of product DTOs
        List<ProductDto> content = products.stream().map(this::mapToDTO).collect(Collectors.toList());

        // Create ProductResponse object and populate it with data
        ProductResponse productResponse = new ProductResponse();
        productResponse.setContent(content);
        productResponse.setPageNo(productsPage.getNumber());
        productResponse.setPageSize(productsPage.getSize());
        productResponse.setTotalElements(productsPage.getTotalElements());
        productResponse.setTotalPages(productsPage.getTotalPages());
        productResponse.setLast(productsPage.isLast());

        return productResponse;
    }

    private ProductDto mapToDTO(Product product) {
        return mapper.map(product, ProductDto.class);
    }

    private Product mapToEntity(ProductDto productDto) {
        return mapper.map(productDto, Product.class);
    }
}