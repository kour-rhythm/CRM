package controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import payload.CampaignDto;
import payload.SendEmailRequest;
import payload.SendSmsRequest; // <--- Import the SendSmsRequest DTO
import service.MarketingService;
@CrossOrigin
@RestController
@RequestMapping("/api/marketing/campaigns")
public class MarketingController {

    private final MarketingService marketingService;

    public MarketingController(MarketingService marketingService) {
        this.marketingService = marketingService;
    }

    @PostMapping
    public ResponseEntity<CampaignDto> createCampaign(@RequestBody CampaignDto campaignDTO) {
        CampaignDto createdCampaign = marketingService.createCampaign(campaignDTO);
        return new ResponseEntity<>(createdCampaign, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CampaignDto> getCampaignById(@PathVariable Integer id) {
        CampaignDto campaign = marketingService.getCampaignById(id);
        if (campaign != null) {
            return new ResponseEntity<>(campaign, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/email")
    public ResponseEntity<List<CampaignDto>> getAllEmailCampaigns() {
        List<CampaignDto> campaigns = marketingService.getAllEmailCampaigns();
        return new ResponseEntity<>(campaigns, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCampaign(@PathVariable Integer id) {
        marketingService.deleteCampaign(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PostMapping("/{campaignId}/send/email")
    public ResponseEntity<String> sendEmailCampaign(
            @PathVariable Integer campaignId,
            @RequestBody SendEmailRequest payload) { // Using a dedicated payload DTO
        String result = marketingService.sendEmailCampaign(campaignId, payload.getCustomerIds(), payload.getProductId(), payload.getSubjectTemplate(), payload.getBodyTemplate());
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    // <--- THIS IS THE CODE THAT WAS LIKELY DELETED / IS NOW RE-ADDED ---
    @PostMapping("/{campaignId}/send/sms")
    public ResponseEntity<String> sendSmsCampaign(
            @PathVariable Integer campaignId,
            @RequestBody SendSmsRequest smsRequest) { // Using the dedicated SendSmsRequest DTO
        String result = marketingService.sendSmsCampaign(
            campaignId,
            smsRequest.getCustomerIds(),
            smsRequest.getProductId(),
            smsRequest.getMessageTemplate()
        );
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
    @PostMapping("/email/events")
    public ResponseEntity<Void> trackEmailEvent(
            @RequestParam("event") String eventType,
            @RequestParam("recipient.email") String recipientEmail,
            @RequestParam("message_id") String messageId,
            @RequestParam(value = "link.url", required = false) String linkUrl) {
        marketingService.trackEmailCampaignEvent(eventType, recipientEmail, messageId, linkUrl);
        return new ResponseEntity<>(HttpStatus.OK);
    }
    @GetMapping("/all") // New endpoint to fetch all campaigns
    public ResponseEntity<List<CampaignDto>> getAllCampaigns() {
        List<CampaignDto> campaigns = marketingService.getAllCampaigns(); // Call the new service method
        return new ResponseEntity<>(campaigns, HttpStatus.OK);
    }

    @GetMapping("/{campaignId}/analyze/email")
    public ResponseEntity<Void> analyzeEmailCampaign(@PathVariable Integer campaignId) {
        marketingService.analyzeEmailCampaignEffectiveness(campaignId);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}