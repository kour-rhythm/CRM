package entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
@Data
@Entity
@Table(name = "campaign")
public class Campaign {
	public Campaign(){
		
	}
    public Campaign(Integer campaignID, String name, LocalDate startDate, LocalDate endDate, CampaignType type,
			String mailerSendCampaignId) {
		super();
		this.campaignID = campaignID;
		this.name = name;
		this.startDate = startDate;
		this.endDate = endDate;
		this.type = type;
		this.mailerSendCampaignId = mailerSendCampaignId;
	}
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer campaignID;

    @Column(nullable = false)
    private String name;

    private LocalDate startDate;
    private LocalDate endDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CampaignType type;

    // Optional: Store MailerSend campaign ID if needed for tracking within MailerSend
    private String mailerSendCampaignId;

}
