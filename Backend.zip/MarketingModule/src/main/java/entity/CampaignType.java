package entity;

public enum CampaignType {
	EMAIL, SMS, SOCIAL_MEDIA
}
