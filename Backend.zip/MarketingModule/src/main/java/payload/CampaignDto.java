// src/main/java/com/yourpackage/dto/CampaignDTO.java
package payload;

import java.time.LocalDate;

import entity.CampaignType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CampaignDto {

    private Integer campaignID;
    private String name;
    private LocalDate startDate;
    private LocalDate endDate;
    private CampaignType type;
    private String mailerSendCampaignId; 

}