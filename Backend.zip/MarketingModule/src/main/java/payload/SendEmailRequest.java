package payload;

import java.util.List;

import lombok.Data;

@Data
public class SendEmailRequest {
    private List<Long> customerIds;
    private Long productId;
    private String subjectTemplate;
    private String bodyTemplate;
}