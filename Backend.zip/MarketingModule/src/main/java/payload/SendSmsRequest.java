package payload;

import java.util.List;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SendSmsRequest {
    private List<Long> customerIds;
    private Long productId;
    private String messageTemplate;
}