// src/main/java/com/yourpackage/services/MarketingService.java
package service;

import java.util.List;

import payload.CampaignDto;

public interface MarketingService {

	CampaignDto createCampaign(CampaignDto campaignDTO);
	CampaignDto getCampaignById(Integer id);
    List<CampaignDto> getAllEmailCampaigns();
    void deleteCampaign(Integer id);
    void trackEmailCampaignEvent(String eventType, String recipientEmail, String messageId, String linkUrl);
    void analyzeEmailCampaignEffectiveness(Integer campaignId);
    List<CampaignDto> getAllCampaigns(); 
	String sendEmailCampaign(Integer campaignId, List<Long> customerIds, Long productId, String subjectTemplate,
			String bodyTemplate);
	String sendSmsCampaign(Integer campaignId, List<Long> customerIds, Long productId, String messageTemplate);	
}
