package service; // This class is now directly in the 'service' package

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import com.twilio.exception.ApiException;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service // Mark this class as a Spring Service
public class TwilioSmsService { // Renamed from TwilioSmsServiceImpl and no longer implements an interface

    @Value("${twilio.account_sid}")
    private String accountSid;

    @Value("${twilio.auth_token}")
    private String authToken;

    @Value("${twilio.trial_number}")
    private String twilioPhoneNumber;

    // This method will be called automatically after the bean is constructed
    @PostConstruct
    public void init() {
        Twilio.init(accountSid, authToken);
        System.out.println("Twilio SDK initialized successfully.");
    }

    /**
     * Sends an SMS message using Twilio.
     *
     * @param toPhoneNumber The recipient's phone number in E.164 format (e.g., +12345678900).
     * @param messageBody The text content of the SMS message.
     * @return true if the SMS was sent successfully, false otherwise.
     */
    public boolean sendSms(String toPhoneNumber, String messageBody) {
        try {
            Message message = Message.creator(
                    new PhoneNumber(toPhoneNumber),    // Recipient's phone number
                    new PhoneNumber(twilioPhoneNumber), // Your Twilio provisioned sender number
                    messageBody                         // SMS message text
            ).create();

            System.out.println("SMS sent successfully! Message SID: " + message.getSid());
            return true;
        } catch (ApiException e) {
            System.err.println("Failed to send SMS via Twilio API. Error Code: " + e.getCode() + ", More Info: " + e.getMoreInfo() + ", Message: " + e.getMessage());
            return false;
        } catch (Exception e) {
            System.err.println("An unexpected error occurred while sending SMS: " + e.getMessage());
            return false;
        }
    }
}