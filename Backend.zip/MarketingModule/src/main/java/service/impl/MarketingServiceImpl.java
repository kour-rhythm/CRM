package service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import entity.Campaign;
import entity.CampaignType;
import payload.CampaignDto;
import repository.CampaignRepository;
import service.MarketingService;
import service.TwilioSmsService; // Corrected import for the consolidated TwilioSmsService

// These DTOs should ideally be in a 'payload' package
// For now, defined here as per your snippet's structure within MarketingServiceImpl
class CustomerResponseDto {
    private Long id; // Assuming customer ID field is 'id' based on previous discussions
    private String emailId;
    private String mobileNo; // Correct field name
    private String name;
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getEmailId() { return emailId; }
    public void setEmailId(String emailId) { this.emailId = emailId; }
    public String getMobileNo() { return mobileNo; } // <--- CORRECTED GETTER NAME (was getMobileNumber)
    public void setMobileNo(String mobileNo) { this.mobileNo = mobileNo; }
    // <--- CORRECTED SETTER NAME (was setMobileNumber)
    public String getName() { return name; } // <--- CORRECTED GETTER NAME (was getMobileNumber)
    public void setName(String name) { this.name = name; }
}

class ProductResponseDto {
    private Long id; // Assuming product ID field is 'id' based on previous discussions
    private String productName;
    private String productBrandName; // Assuming brand name field is this
    private String productBrandDescription;
    private double productPrice;
    private int productReviewOutOfFive; // Assuming review field is this

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }
    public String getProductBrandName() { return productBrandName; }
    public void setProductBrandName(String productBrandName) { this.productBrandName = productBrandName; }
    public String getProductBrandDescription() { return productBrandDescription; }
    public void setProductBrandDescription(String productBrandDescription) { this.productBrandDescription = productBrandDescription; }
    public double getProductPrice() { return productPrice; }
    public void setProductPrice(double productPrice) { this.productPrice = productPrice; }
    public int getProductReviewOutOfFive() { return productReviewOutOfFive; }
    public void setProductReviewOutOfFive(int productReviewOutOfFive) { this.productReviewOutOfFive = productReviewOutOfFive; }
}


@Service
public class MarketingServiceImpl implements MarketingService {

    private final CampaignRepository campaignRepository;
    private final WebClient.Builder webClientBuilder;

    @Autowired
    private JavaMailSender javaMailSender;

    // CHANGED: Autowiring the consolidated TwilioSmsService directly
    @Autowired
    private TwilioSmsService twilioSmsService; 

    public MarketingServiceImpl(CampaignRepository campaignRepository, WebClient.Builder webClientBuilder) {
        this.campaignRepository = campaignRepository;
        this.webClientBuilder = webClientBuilder;
    }

    @Override
    public CampaignDto createCampaign(CampaignDto campaignDTO) {
        Campaign campaign = convertToEntity(campaignDTO);
        // FIX: Use the type from the DTO instead of hardcoding to EMAIL
        if (campaignDTO.getType() != null) {
            campaign.setType(campaignDTO.getType());
        } else {
            // Optional: Set a default type if none is provided in the DTO
            campaign.setType(CampaignType.EMAIL); // Or throw an error, depending on requirements
        }
        Campaign savedCampaign = campaignRepository.save(campaign);
        return convertToDTO(savedCampaign);
    }

    @Override
    public CampaignDto getCampaignById(Integer id) {
        return campaignRepository.findById(id)
                .map(this::convertToDTO)
                .orElse(null);
    }

    @Override
    public List<CampaignDto> getAllEmailCampaigns() {
        return campaignRepository.findByType(CampaignType.EMAIL)
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public void deleteCampaign(Integer id) {
        campaignRepository.deleteById(id);
    }

    @Override
    public String sendEmailCampaign(Integer campaignId, List<Long> customerIds, Long productId, String subjectTemplate, String bodyTemplate) {
        CampaignDto campaignDTO = getCampaignById(campaignId);
        if (campaignDTO == null || campaignDTO.getType() != CampaignType.EMAIL) {
            return "Campaign not found or not an email campaign.";
        }

        ProductResponseDto product = null;
        try {
            product = webClientBuilder.build().get()
                    .uri("http://CustomerModule/api/products/{id}", productId)
                    .retrieve()
                    .bodyToMono(ProductResponseDto.class)
                    .block();
        } catch (Exception e) {
            return "Error fetching product details for ID " + productId + ": " + e.getMessage();
        }


        if (product == null) {
            return "Product with ID " + productId + " not found from Product Service.";
        }

        List<CustomerResponseDto> customers = null;
        try {
            customers = webClientBuilder.build().get()
                    .uri(uriBuilder -> uriBuilder.scheme("http").host("CustomerModule")
                                    .path("/api/customers/by-ids") // Added leading slash for clarity
                                    .queryParam("ids", customerIds.stream().map(String::valueOf).collect(Collectors.joining(",")))
                                    .build())
                    .retrieve()
                    .bodyToFlux(CustomerResponseDto.class)
                    .collectList()
                    .block();
        } catch (Exception e) {
            return "Error fetching customers for email campaign: " + e.getMessage();
        }


        if (customers == null || customers.isEmpty()) {
            return "No customers found with the provided IDs from Customer Service.";
        }

        List<String> errors = new ArrayList<>();
        for (CustomerResponseDto customer : customers) {
            String recipientEmail = customer.getEmailId();
            String personalizedSubject = replaceProductDetailsInEmail(subjectTemplate, product);
            String personalizedBody = replaceProductDetailsInEmail(bodyTemplate, product);

            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("your-gmail-address@gmail.com"); // Replace with your sender email
            message.setTo(recipientEmail);
            message.setSubject(personalizedSubject);
            message.setText(personalizedBody);

            try {
                javaMailSender.send(message);
                System.out.println("Email sent successfully to " + recipientEmail);
            } catch (Exception e) {
                System.err.println("Error sending email to " + recipientEmail + ": " + e.getMessage());
                errors.add("Error sending email to " + recipientEmail + ": " + e.getMessage());
            }
        }

        if (errors.isEmpty()) {
            return "Email campaign sent successfully to all recipients.";
        } else {
            return "Email campaign sent with some errors: " + String.join("; ", errors);
        }
    }

    @Override
    public String sendSmsCampaign(Integer campaignId, List<Long> customerIds, Long productId, String messageTemplate) {
        CampaignDto campaignDTO = getCampaignById(campaignId);
        // Assuming your Campaign entity has a type to differentiate between SMS and Email campaigns
        // You might need to adjust createCampaign or add a new createSmsCampaign method to set type to SMS
        // if (campaignDTO == null || campaignDTO.getType() != CampaignType.SMS) {
        //     return "Campaign not found or not an SMS campaign.";
        // }

        // 1. Fetch Product Details
        ProductResponseDto product = null;
        if (productId != null) {
            try {
                product = webClientBuilder.build().get()
                        .uri("http://CustomerModule/api/products/{id}", productId)
                        .retrieve()
                        .bodyToMono(ProductResponseDto.class)
                        .block();
            } catch (Exception e) {
                return "Error fetching product details for ID " + productId + ": " + e.getMessage();
            }
        }

        if (product == null && productId != null) {
             return "Product with ID " + productId + " not found. Cannot send SMS campaign.";
        }

        // 2. Fetch Customer details (especially phone numbers)
        List<CustomerResponseDto> customers = null;
        if (customerIds != null && !customerIds.isEmpty()) {
            try {
                customers = webClientBuilder.build().get()
                        .uri(uriBuilder -> uriBuilder.scheme("http").host("CustomerModule")
                                        .path("/api/customers/by-ids")
                                        .queryParam("ids", customerIds.stream().map(String::valueOf).collect(Collectors.joining(",")))
                                        .build())
                        .retrieve()
                        .bodyToFlux(CustomerResponseDto.class)
                        .collectList()
                        .block();
            } catch (Exception e) {
                return "Error fetching customers for SMS campaign: " + e.getMessage();
            }
        }


        if (customers == null || customers.isEmpty()) {
            return "No customers found for SMS campaign.";
        }

        // 3. Iterate and send SMS to each customer
        int sentCount = 0;
        List<String> errors = new ArrayList<>();
        for (CustomerResponseDto customer : customers) {
            String customerPhoneNumber = customer.getMobileNo(); // Uses the corrected getMobileNo()
            if (customerPhoneNumber != null && !customerPhoneNumber.isEmpty()) {
                // Construct the personalized message
                String finalMessage = replaceProductDetailsInSms(messageTemplate, customer, product);

                // Ensure the phone number is in E.164 format (e.g., +12345678900)
                // You might need to add logic here to format numbers if they are not already.
                // Example: if (!customerPhoneNumber.startsWith("+")) customerPhoneNumber = "+91" + customerPhoneNumber;
                if (!customerPhoneNumber.startsWith("+")) {
                    System.err.println("Warning: Phone number " + customerPhoneNumber + " for customer " + customer.getId() + " is not in E.164 format (e.g., +12345678900). Attempting to send as-is, but Twilio may reject.");
                    errors.add("Phone number for customer " + customer.getId() + " not in E.164 format.");
                }

                boolean success = twilioSmsService.sendSms(customerPhoneNumber, finalMessage);
                if (success) {
                    sentCount++;
                } else {
                    errors.add("Failed to send SMS to " + customerPhoneNumber + " for customer " + customer.getId());
                }
            } else {
                System.err.println("Customer " + customer.getId() + " has no mobile number, skipping SMS.");
                errors.add("Customer " + customer.getId() + " has no mobile number.");
            }
        }

        if (errors.isEmpty()) {
            return "SMS campaign initiated successfully. Messages sent to " + sentCount + " customers.";
        } else {
            return "SMS campaign initiated with " + sentCount + " successful messages and some errors: " + String.join("; ", errors);
        }
    }


    // Helper method to replace product details in the email content
    // Adjusted to match ProductResponseDto
    private String replaceProductDetailsInEmail(String template, ProductResponseDto product) {
        String result = template.replace("{{product.name}}", product.getProductName() != null ? product.getProductName() : "");
        result = result.replace("{{product.description}}", product.getProductBrandDescription() != null ? product.getProductBrandDescription() : "");
        result = result.replace("{{product.price}}", String.valueOf(product.getProductPrice()));
        // Add more replacements for other product fields as needed
        return result;
    }

    // NEW Helper method for SMS message templating
    private String replaceProductDetailsInSms(String template, CustomerResponseDto customer, ProductResponseDto product) {
        String result = template.replace("{customerName}", customer.getName() != null ? customer.getName().toString() : "Valued Customer"); // Using ID as placeholder for name
        // You might want a 'firstName' or 'name' field in CustomerResponseDto for better personalization

        if (product != null) {
            result = result.replace("{productName}", product.getProductName() != null ? product.getProductName() : "");
            result = result.replace("{productBrand}", product.getProductBrandName() != null ? product.getProductBrandName() : "");
            result = result.replace("{productDescription}", product.getProductBrandDescription() != null ? product.getProductBrandDescription() : "");
            result = result.replace("{productPrice}", String.valueOf(product.getProductPrice()));
            result = result.replace("{productReview}", String.valueOf(product.getProductReviewOutOfFive()));
        }
        return result;
    }
    @Override
    public List<CampaignDto> getAllCampaigns() { // NEW method implementation
        return campaignRepository.findAll() // Fetches all campaigns from the database
                .stream()
                .map(this::convertToDTO) // Converts each Campaign entity to CampaignDto
                .collect(Collectors.toList());
    }

    @Override
    public void trackEmailCampaignEvent(String eventType, String recipientEmail, String messageId, String linkUrl) {
        System.out.println("Tracking email event is not directly applicable with JavaMail. You would need to implement your own tracking mechanisms (e.g., embedding tracking pixels or links).");
    }

    @Override
    public void analyzeEmailCampaignEffectiveness(Integer campaignId) {
        System.out.println("Analyzing email campaign effectiveness requires custom implementation when using JavaMail (e.g., parsing bounce messages, tracking opens via embedded images if implemented).");
    }

    private Campaign convertToEntity(CampaignDto campaignDTO) {
        Campaign campaign = new Campaign();
        campaign.setCampaignID(campaignDTO.getCampaignID());
        campaign.setName(campaignDTO.getName());
        campaign.setStartDate(campaignDTO.getStartDate());
        campaign.setEndDate(campaignDTO.getEndDate());
        campaign.setType(campaignDTO.getType());
        campaign.setMailerSendCampaignId(campaignDTO.getMailerSendCampaignId());
        return campaign;
    }

    private CampaignDto convertToDTO(Campaign campaign) {
        return new CampaignDto(
                campaign.getCampaignID(),
                campaign.getName(),
                campaign.getStartDate(),
                campaign.getEndDate(),
                campaign.getType(),
                campaign.getMailerSendCampaignId()
        );
    }
}