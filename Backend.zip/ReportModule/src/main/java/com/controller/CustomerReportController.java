package com.controller;

import com.exception.CrmAPIException;
import com.exception.ResourceNotFoundException;
import com.payload.CustomerReportBatchRequestDto;
import com.payload.CustomerReportDto;
import com.service.CustomerReportService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.List;

// This controller handles API requests related to customer reports.
@CrossOrigin
@RestController
@RequestMapping("/api/customer") // Base path for customer-related endpoints
public class CustomerReportController {

    private final CustomerReportService customerReportService;

    public CustomerReportController(CustomerReportService customerReportService) {
        this.customerReportService = customerReportService;
    }

    /**
     * Retrieves a detailed report for a single customer by their ID.
     * GET /api/customer/{customerId}/report
     *
     * @param customerId The ID of the customer to retrieve the report for.
     * @return A Mono emitting ResponseEntity with CustomerReportDto if found,
     * or appropriate error status (404, 500).
     */
    @GetMapping("/{customerId}/report")
    public Mono<ResponseEntity<CustomerReportDto>> getCustomerReport(@PathVariable Long customerId) {
        return customerReportService.getCustomerReport(customerId)
                .map(ResponseEntity::ok) // If the Mono emits a DTO, wrap it in an OK response
                .onErrorResume(ResourceNotFoundException.class, ex -> {
                    // Handle ResourceNotFoundException specifically for 404 Not Found
                    return Mono.just(new ResponseEntity<>(HttpStatus.NOT_FOUND));
                })
                .onErrorResume(CrmAPIException.class, ex -> {
                    // Handle custom CrmAPIException to return appropriate HTTP status and message
                    return Mono.just(new ResponseEntity<>(HttpStatus.BAD_REQUEST));
                })
                .onErrorResume(Exception.class, ex -> {
                    // Catch any other unexpected exceptions and return a 500 Internal Server Error
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }
    @GetMapping("/report/all")
    public Mono<ResponseEntity<List<CustomerReportDto>>> getAllCustomerReports() {
        return customerReportService.getAllCustomerReports() // Call the new service method
                .map(ResponseEntity::ok)
                .onErrorResume(Exception.class, ex -> {
                    System.err.println("Error fetching all customer reports: " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }
    /**
     * Handles batch retrieval of customer reports.
     * POST /api/customer/report/batch
     *
     * @param requestDto DTO containing a list of customer IDs for which to retrieve reports.
     * @return A Mono emitting ResponseEntity with a List of CustomerReportDto.
     */
//    @PostMapping("/report/ba tch")
//    public Mono<ResponseEntity<List<CustomerReportDto>>> getCustomerReportsBatch(@RequestBody CustomerReportBatchRequestDto requestDto) {
//        // Validate if the list of IDs is not null or empty
//        if (requestDto.getCustomerIds() == null || requestDto.getCustomerIds().isEmpty()) {
//            return Mono.just(new ResponseEntity<>(HttpStatus.BAD_REQUEST));
//        }
//
//        return customerReportService.getCustomerReports(requestDto.getCustomerIds())
//                .map(ResponseEntity::ok)
//                .onErrorResume(Exception.class, ex -> {
//                    // Catch any unexpected exceptions during the batch process
//                    System.err.println("Error processing batch customer reports: " + ex.getMessage());
//                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
//                });
//    }
//
//    /**
//     * Retrieves detailed reports for all customers.
//     * GET /api/customer/report/all
//     *
//     * @return A Mono emitting ResponseEntity with a List of CustomerReportDto.
//     */
//    @GetMapping("/report/all")
//    public Mono<ResponseEntity<List<CustomerReportDto>>> getAllCustomerReports() {
//        return customerReportService.getAllCustomerReports()
//                .map(ResponseEntity::ok)
//                .onErrorResume(Exception.class, ex -> {
//                    // Catch any unexpected exceptions during the "get all" process
//                    System.err.println("Error fetching all customer reports: " + ex.getMessage());
//                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
//                });
//    }
//
//    /**
//     * Generates and saves a customer report for a given customer ID.
//     * POST /api/customer/{customerId}/report/generate
//     *
//     * @param customerId The ID of the customer for whom to generate and save the report.
//     * @return A Mono emitting ResponseEntity with the saved CustomerReportDto.
//     */
    @PostMapping("/{customerId}/report/generate")
    public Mono<ResponseEntity<CustomerReportDto>> generateAndSaveCustomerReport(@PathVariable Long customerId) {
        return customerReportService.generateAndSaveCustomerReport(customerId)
                .map(reportDto -> new ResponseEntity<>(reportDto, HttpStatus.CREATED)) // Return 201 Created for new resource
                .onErrorResume(ResourceNotFoundException.class, ex -> {
                    System.err.println("Generate Report: " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.NOT_FOUND));
                })
                .onErrorResume(CrmAPIException.class, ex -> {
                    System.err.println("Generate Report API Error: " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.BAD_REQUEST));
                })
                .onErrorResume(Exception.class, ex -> {
                    System.err.println("Unexpected error generating customer report: " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }
}
