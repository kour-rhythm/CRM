package com.controller;

import com.exception.CrmAPIException;
import com.exception.ResourceNotFoundException;
import com.payload.MarketingReportDto; // DTO for campaign details from external module
import com.payload.MarketingReportResponseDto; // DTO for locally saved marketing reports
import com.service.MarketingReportService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * REST Controller for Marketing Reports.
 * This controller provides endpoints to retrieve marketing campaign data
 * from the external Marketing Module and to trigger the generation
 * and saving of marketing reports within this service's database. It also
 * allows retrieval of saved marketing reports.
 */
@CrossOrigin
@RestController
@RequestMapping("/api/marketingreports") // Base path for marketing report endpoints
public class MarketingReportController {

    private final MarketingReportService marketingReportService;

    /**
     * Constructor for MarketingReportController.
     * Spring automatically injects the MarketingReportService.
     *
     * @param marketingReportService The service handling marketing report business logic.
     */
    public MarketingReportController(MarketingReportService marketingReportService) {
        this.marketingReportService = marketingReportService;
    }

    /**
     * Retrieves a detailed marketing campaign from the external Marketing Module by its ID.
     * GET /api/marketingreports/{campaignId}
     *
     * @param campaignId The ID of the marketing campaign to retrieve details for (Long).
     * @return A Mono emitting ResponseEntity with MarketingReportDto if found,
     * or appropriate error status (400, 404, 500).
     */
    @GetMapping("/{campaignId}")
    public Mono<ResponseEntity<MarketingReportDto>> getMarketingCampaign(@PathVariable Long campaignId) { // Changed to Long
        return marketingReportService.getMarketingCampaign(campaignId)
                .map(ResponseEntity::ok)
                .onErrorResume(ResourceNotFoundException.class, ex -> {
                    System.err.println("Marketing Report Controller: ResourceNotFoundException for campaign " + campaignId + ": " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.NOT_FOUND));
                })
                .onErrorResume(CrmAPIException.class, ex -> {
                    System.err.println("Marketing Report Controller: CrmAPIException for campaign " + campaignId + ": " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.BAD_REQUEST));
                })
                .onErrorResume(Exception.class, ex -> {
                    System.err.println("Marketing Report Controller: Unexpected error for campaign " + campaignId + ": " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }

    /**
     * Retrieves detailed marketing campaigns for all marketing campaigns from the external Marketing Module.
     * GET /api/marketingreports/all
     *
     * @return A Mono emitting ResponseEntity with a List of MarketingReportDto.
     */
    @GetMapping("/all")
    public Mono<ResponseEntity<List<MarketingReportDto>>> getAllMarketingCampaigns() {
        return marketingReportService.getAllMarketingCampaigns()
                .collectList()
                .map(ResponseEntity::ok)
                .onErrorResume(Exception.class, ex -> {
                    System.err.println("Marketing Report Controller: Error fetching all marketing campaigns: " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }

    /**
     * Generates and saves a marketing report for a given campaign ID.
     * This endpoint triggers the process of fetching data from the external service
     * and persisting it in the local database.
     * POST /api/marketingreports/{campaignId}/generate
     *
     * @param campaignId The ID of the marketing campaign for which to generate and save the report (Long).
     * @return A Mono emitting ResponseEntity with the saved MarketingReportResponseDto.
     */
    @PostMapping("/{campaignId}/generate")
    public Mono<ResponseEntity<MarketingReportResponseDto>> generateAndSaveMarketingReport(@PathVariable Long campaignId) { // Remains Long
        return marketingReportService.generateAndSaveMarketingReport(campaignId)
                .map(reportDto -> new ResponseEntity<>(reportDto, HttpStatus.CREATED))
                .onErrorResume(ResourceNotFoundException.class, ex -> {
                    System.err.println("Generate Marketing Report: " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.BAD_REQUEST));
                })
                .onErrorResume(CrmAPIException.class, ex -> {
                    System.err.println("Generate Marketing Report API Error: " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.BAD_REQUEST));
                })
                .onErrorResume(Exception.class, ex -> {
                    System.err.println("Unexpected error generating marketing report: " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }

    /**
     * Retrieves a saved Marketing Report from the local database by its ID.
     * The ID here refers to the campaignId, which is now the primary key of the stored report.
     * GET /api/marketingreports/saved/{campaignId}
     *
     * @param campaignId The ID of the saved marketing report (which is the campaignId) (Long).
     * @return A Mono emitting ResponseEntity with MarketingReportResponseDto if found, or 404 Not Found.
     */
    @GetMapping("/saved/{campaignId}")
    public Mono<ResponseEntity<MarketingReportResponseDto>> getSavedMarketingReportById(@PathVariable Long campaignId) { // Changed to Long
        return marketingReportService.getSavedMarketingReportById(campaignId)
                .map(ResponseEntity::ok)
                .onErrorResume(ResourceNotFoundException.class, ex -> {
                    System.err.println("Get Saved Marketing Report: " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.NOT_FOUND));
                })
                .onErrorResume(Exception.class, ex -> {
                    System.err.println("Unexpected error retrieving saved marketing report: " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }

    /**
     * Retrieves all saved Marketing Reports from the local database.
     * GET /api/marketingreports/saved/all
     *
     * @return A Mono emitting ResponseEntity with a List of MarketingReportResponseDto.
     */
    @GetMapping("/saved/all")
    public Mono<ResponseEntity<List<MarketingReportResponseDto>>> getAllSavedMarketingReports() {
        return marketingReportService.getAllSavedMarketingReports()
                .collectList()
                .map(ResponseEntity::ok)
                .onErrorResume(Exception.class, ex -> {
                    System.err.println("Error fetching all saved marketing reports: " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }
}
