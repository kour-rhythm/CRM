package com.controller;

import com.exception.CrmAPIException;
import com.exception.ResourceNotFoundException;
import com.payload.SalesOpportunityResponseDto; // The DTO expected from the external Sales Opportunity Service
import com.service.SalesReportService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * REST Controller for Sales Reports.
 * This controller provides endpoints to retrieve sales opportunity data
 * from the external Sales Opportunity Service and to trigger the generation
 * and saving of sales reports within this service's database.
 */
@CrossOrigin
@RestController
@RequestMapping("/api/salesreports") // Base path for sales report endpoints
public class SalesReportController {

    private final SalesReportService salesReportService;

    /**
     * Constructor for SalesReportController.
     * Spring automatically injects the SalesReportService.
     *
     * @param salesReportService The service handling sales report business logic.
     */
    public SalesReportController(SalesReportService salesReportService) {
        this.salesReportService = salesReportService;
    }

    /**
     * Retrieves a detailed sales report for a single sales opportunity by its ID.
     * GET /api/salesreports/{opportunityId}
     *
     * @param opportunityId The ID of the sales opportunity to retrieve the report for.
     * @return A Mono emitting ResponseEntity with SalesOpportunityResponseDto if found,
     * or appropriate error status (404, 500).
     */
    @GetMapping("/{opportunityId}")
    public Mono<ResponseEntity<SalesOpportunityResponseDto>> getSalesReport(@PathVariable Long opportunityId) {
        return salesReportService.getSalesReport(opportunityId)
                .map(ResponseEntity::ok) // If the Mono emits a DTO, wrap it in an OK response
                .onErrorResume(ResourceNotFoundException.class, ex -> {
                    // Handle ResourceNotFoundException specifically for 404 Not Found
                    System.err.println("Sales Report Controller: ResourceNotFoundException for opportunity " + opportunityId + ": " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.NOT_FOUND));
                })
                .onErrorResume(CrmAPIException.class, ex -> {
                    // Handle custom CrmAPIException to return appropriate HTTP status and message
                    System.err.println("Sales Report Controller: CrmAPIException for opportunity " + opportunityId + ": " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.BAD_REQUEST));
                })
                .onErrorResume(Exception.class, ex -> {
                    // Catch any other unexpected exceptions and return a 500 Internal Server Error
                    System.err.println("Sales Report Controller: Unexpected error for opportunity " + opportunityId + ": " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }

    /**
     * Retrieves detailed sales reports for all sales opportunities.
     * This endpoint fetches all opportunities from the external service.
     * GET /api/salesreports/all
     *
     * @return A Mono emitting ResponseEntity with a List of SalesOpportunityResponseDto.
     */
    @GetMapping("/all")
    public Mono<ResponseEntity<List<SalesOpportunityResponseDto>>> getAllSalesReports() {
        // Collect Flux into a List<SalesOpportunityResponseDto> for the ResponseEntity.
        // It's generally preferred to return Flux directly if clients can handle streaming,
        // but Mono<List<T>> is common for aggregated results.
        return salesReportService.getAllSalesReports()
                .collectList() // Collect all items emitted by the Flux into a single List
                .map(ResponseEntity::ok)
                .onErrorResume(Exception.class, ex -> {
                    // Catch any unexpected exceptions during the "get all" process
                    System.err.println("Sales Report Controller: Error fetching all sales opportunities: " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }

    /**
     * Generates and saves a sales report for a given sales opportunity ID.
     * This endpoint triggers the process of fetching data from the external service
     * and persisting it in the local database.
     * POST /api/salesreports/{opportunityId}/generate
     *
     * @param opportunityId The ID of the sales opportunity for which to generate and save the report.
     * @return A Mono emitting ResponseEntity with the saved SalesOpportunityResponseDto.
     */
    @PostMapping("/{opportunityId}/generate")
    public Mono<ResponseEntity<SalesOpportunityResponseDto>> generateAndSaveSalesReport(@PathVariable Long opportunityId) {
        return salesReportService.generateAndSaveSalesReport(opportunityId)
                .map(reportDto -> new ResponseEntity<>(reportDto, HttpStatus.CREATED)) // Return 201 Created for new resource
                .onErrorResume(ResourceNotFoundException.class, ex -> {
                    System.err.println("Generate Sales Report: " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.NOT_FOUND));
                })
                .onErrorResume(CrmAPIException.class, ex -> {
                    System.err.println("Generate Sales Report API Error: " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.BAD_REQUEST));
                })
                .onErrorResume(Exception.class, ex -> {
                    System.err.println("Unexpected error generating sales report: " + ex.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }
}
