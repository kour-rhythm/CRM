package com.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

// This entity represents a stored snapshot or cached version of a customer report.
// It contains all customer behavior details, fetched from the external module.
@Entity
@Table(name = "customer_reports") // Define the table name
public class CustomerReport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "customer_id", nullable = false, unique = true)
    private Long customerId;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "customer_email_id")
    private String customerEmail;

    @Column(name = "no_of_orders")
    private Integer noOfOrders;

    @Column(name = "most_recent_order_date")
    private LocalDateTime mostRecentOrderDate;

    @Column(name = "generated_at", nullable = false)
    private LocalDateTime generatedAt; // Timestamp when this report was generated/stored

    // Default constructor
    public CustomerReport() {
        this.generatedAt = LocalDateTime.now(); // Set generation time upon creation
    }

    // Constructor with all fields
    public CustomerReport(Long customerId, String customerName, String customerEmail,
                          Integer noOfOrders, LocalDateTime mostRecentOrderDate) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerEmail = customerEmail;
        this.noOfOrders = noOfOrders;
        this.mostRecentOrderDate = mostRecentOrderDate;
        this.generatedAt = LocalDateTime.now();
    }

    // --- Getters and Setters ---

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public Integer getNoOfOrders() {
        return noOfOrders;
    }

    public void setNoOfOrders(Integer noOfOrders) {
        this.noOfOrders = noOfOrders;
    }

    public LocalDateTime getMostRecentOrderDate() {
        return mostRecentOrderDate;
    }

    public void setMostRecentOrderDate(LocalDateTime mostRecentOrderDate) {
        this.mostRecentOrderDate = mostRecentOrderDate;
    }

    public LocalDateTime getGeneratedAt() {
        return generatedAt;
    }

    public void setGeneratedAt(LocalDateTime generatedAt) {
        this.generatedAt = generatedAt;
    }
}
