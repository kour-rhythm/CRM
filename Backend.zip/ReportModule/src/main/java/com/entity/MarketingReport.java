package com.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Entity representing a stored snapshot or cached version of a marketing report.
 * This entity includes all relevant fields from the external Campaign entity,
 * with the campaign's ID (now Long) serving as the primary key for the report itself.
 */
@Entity
@Table(name = "marketing_reports") // Define the table name for marketing reports
public class MarketingReport {

    @Id // The campaignId from the original Campaign entity now serves as the primary key for this report
    @Column(name = "campaign_id", nullable = false)
    private Long campaignID; // Changed to Long: Corresponds to campaignID in the external Campaign entity

    @Column(name = "campaign_name", nullable = false)
    private String name; // Corresponds to 'name' in the external Campaign entity

    @Column(name = "start_date")
    private LocalDate startDate; // Corresponds to 'startDate' in the external Campaign entity

    @Column(name = "end_date")
    private LocalDate endDate; // Corresponds to 'endDate' in the external Campaign entity

    @Column(name = "campaign_type", nullable = false)
    private String type; // Corresponds to 'type' in the external Campaign entity (stored as String)

    @Column(name = "mailer_send_campaign_id")
    private String mailerSendCampaignId; // Corresponds to 'mailerSendCampaignId' in the external Campaign entity

    @Column(name = "generated_at", nullable = false)
    private LocalDateTime generatedAt; // Timestamp when this report was generated/stored

    // Default constructor
    public MarketingReport() {
        this.generatedAt = LocalDateTime.now(); // Set generation time upon creation
    }

    /**
     * Constructor with all fields from the external Campaign entity, plus generatedAt.
     *
     * @param campaignId The ID of the original campaign (Long).
     * @param name The name of the campaign.
     * @param startDate The start date of the campaign.
     * @param endDate The end date of the campaign.
     * @param type The type of the campaign (e.g., "EMAIL", "SMS").
     * @param mailerSendCampaignId The MailerSend campaign ID, if applicable.
     */
    public MarketingReport(Long campaignID, String name, LocalDate startDate, LocalDate endDate,
                           String type, String mailerSendCampaignId) {
        this.campaignID = campaignID;
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.type = type;
        this.mailerSendCampaignId = mailerSendCampaignId;
        this.generatedAt = LocalDateTime.now(); // Set generation time upon creation
    }

    // --- Getters and Setters ---
    public Long getcampaignID() {
        return campaignID;
    }

    public void setcampaignID(Long campaignID) {
        this.campaignID = campaignID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMailerSendCampaignId() {
        return mailerSendCampaignId;
    }

    public void setMailerSendCampaignId(String mailerSendCampaignId) {
        this.mailerSendCampaignId = mailerSendCampaignId;
    }

    public LocalDateTime getGeneratedAt() {
        return generatedAt;
    }

    public void setGeneratedAt(LocalDateTime generatedAt) {
        this.generatedAt = generatedAt;
    }
}
