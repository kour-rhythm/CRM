package com.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

// This entity represents a stored snapshot or cached version of a sales report.
// It will contain key details from a sales opportunity, fetched from the external Sales Opportunity Service.
@Entity
@Table(name = "sales_reports") // Define the table name for sales reports
public class SalesReport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Primary key for this sales report entity

    @Column(name = "opportunity_id", nullable = false, unique = true)
    private Long opportunityId; // The ID of the original sales opportunity

    @Column(name = "opportunity_name", nullable = false)
    private String name;

    @Column(name = "opportunity_stage", nullable = false)
    private String stage;

    @Column(name = "opportunity_amount")
    private Double amount;

    @Column(name = "opportunity_close_date")
    private LocalDate closeDate;

    @Column(name = "opportunity_lead_source")
    private String leadSource;

    @Column(name = "opportunity_notes", length = 1000)
    private String notes;

    @Column(name = "generated_at", nullable = false)
    private LocalDateTime generatedAt; // Timestamp when this report was generated/stored

    // Default constructor
    public SalesReport() {
        this.generatedAt = LocalDateTime.now(); // Set generation time upon creation
    }

    // Constructor with all relevant fields from a SalesOpportunity
    public SalesReport(Long opportunityId, String name, String stage, Double amount,
                       LocalDate closeDate, String leadSource, String notes) {
        this.opportunityId = opportunityId;
        this.name = name;
        this.stage = stage;
        this.amount = amount;
        this.closeDate = closeDate;
        this.leadSource = leadSource;
        this.notes = notes;
        this.generatedAt = LocalDateTime.now(); // Set generation time upon creation
    }

    // --- Getters and Setters ---

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getOpportunityId() {
        return opportunityId;
    }

    public void setOpportunityId(Long opportunityId) {
        this.opportunityId = opportunityId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public LocalDate getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(LocalDate closeDate) {
        this.closeDate = closeDate;
    }

    public String getLeadSource() {
        return leadSource;
    }

    public void setLeadSource(String leadSource) {
        this.leadSource = leadSource;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public LocalDateTime getGeneratedAt() {
        return generatedAt;
    }

    public void setGeneratedAt(LocalDateTime generatedAt) {
        this.generatedAt = generatedAt;
    }
}
