package com.example.demo; // Adjust package name if different

import java.util.concurrent.TimeUnit;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
// Import additional security auto-configurations to explicitly exclude them
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.cache.CacheManager;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.boot.autoconfigure.security.reactive.ReactiveSecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.security.oauth2.client.servlet.OAuth2ClientAutoConfiguration;
import org.springframework.boot.autoconfigure.security.saml2.Saml2RelyingPartyAutoConfiguration;
import org.springframework.context.annotation.Bean;
// Removed redundant ComponentScan: import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.reactive.function.client.WebClient;

import com.github.benmanes.caffeine.cache.Caffeine;

import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;

@SpringBootApplication(
    scanBasePackages = {
        "com.example.demo",
        "com.controller",
        "com.service.impl", // Ensure service implementation is scanned
        "com.repository",
        "com.service",
        "com.entity",
        "com.payload"
    },
    // EXCLUDE ALL KNOWN SPRING SECURITY AUTO-CONFIGURATIONS
    exclude = {
        SecurityAutoConfiguration.class,           // Standard servlet security
        ReactiveSecurityAutoConfiguration.class,   // Reactive web security (for WebFlux)
        OAuth2ClientAutoConfiguration.class,       // OAuth2 client security
        Saml2RelyingPartyAutoConfiguration.class   // SAML2 security
    }
)
// Removed redundant @ComponentScan(basePackages = "com")
@EntityScan(basePackages = {"com.entity"}) // Tell JPA where to find your @Entity classes
@EnableJpaRepositories(basePackages = "com.repository") // Tell JPA where to find your Repositories
@EnableDiscoveryClient // Enables this application to register with Eureka and use Eureka-aware WebClient
public class ReportGeneration {
	@Bean
    @LoadBalanced
    public WebClient.Builder webClientBuilder() {
        return WebClient.builder();
    }

    @Bean
    public Caffeine<Object, Object> caffeineConfig() {
        return Caffeine.newBuilder()
                       .expireAfterWrite(60, TimeUnit.MINUTES)
                       .maximumSize(1000);
    }

    @Bean
    public CacheManager cacheManager(Caffeine<Object, Object> caffeine) {
        CaffeineCacheManager manager = new CaffeineCacheManager();
        manager.setCaffeine(caffeine);
        return manager;
    }
	@Bean // Bean for ModelMapper, used for DTO-entity conversions
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}

	public static void main(String[] args) {
		SpringApplication.run(ReportGeneration.class, args);
	}
}
