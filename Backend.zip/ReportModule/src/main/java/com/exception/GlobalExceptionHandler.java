package com.exception;

import com.payload.ErrorDetails;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.support.WebExchangeBindException; // For WebFlux validation errors
import org.springframework.web.server.ServerWebExchange; // WebFlux equivalent of WebRequest
import reactor.core.publisher.Mono; // For reactive return types

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class GlobalExceptionHandler { // No longer extends ResponseEntityExceptionHandler

    // Handle ResourceNotFoundException
    @ExceptionHandler(ResourceNotFoundException.class)
    public Mono<ResponseEntity<ErrorDetails>> handleResourceNotFoundException(ResourceNotFoundException exception,
                                                                              ServerWebExchange exchange) {
        ErrorDetails errorDetails = new ErrorDetails(new Date(), exception.getMessage(),
                exchange.getRequest().getPath().toString()); // Get request path for error description
        return Mono.just(new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND));
    }

    // Handle CrmAPIException
    @ExceptionHandler(CrmAPIException.class)
    public Mono<ResponseEntity<ErrorDetails>> handleCrmAPIException(CrmAPIException exception,
                                                                     ServerWebExchange exchange) {
        ErrorDetails errorDetails = new ErrorDetails(new Date(), exception.getMessage(),
                exchange.getRequest().getPath().toString());
        return Mono.just(new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST));
    }

    // Handle Global Exception (catch-all for unexpected errors)
    @ExceptionHandler(Exception.class)
    public Mono<ResponseEntity<ErrorDetails>> handleGlobalException(Exception exception,
                                                                    ServerWebExchange exchange) {
        ErrorDetails errorDetails = new ErrorDetails(new Date(), exception.getMessage(),
                exchange.getRequest().getPath().toString());
        return Mono.just(new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR));
    }

    // Handle Validation Errors for Spring WebFlux
    @ExceptionHandler(WebExchangeBindException.class)
    public Mono<ResponseEntity<Map<String, String>>> handleWebExchangeBindException(WebExchangeBindException ex,
                                                                                    ServerWebExchange exchange) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String message = error.getDefaultMessage();
            errors.put(fieldName, message);
        });

        return Mono.just(new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST));
    }
}
