package com.payload;

import java.time.LocalDateTime;

// This DTO represents the comprehensive response structure from the external CustomerDataModule
// when querying for customer behavior details.
public class CustomerBehaviorDetailDto {
    private Long customerId;
    private String customerName;
    private String customerEmail;
    private Integer noOfOrders;
    private LocalDateTime mostRecentOrderDate;

    // Default constructor for deserialization
    public CustomerBehaviorDetailDto() {
    }

    // Constructor based on the provided example
    public CustomerBehaviorDetailDto(Long customerId, String customerName, String customerEmail,
                                     Integer noOfOrders, LocalDateTime mostRecentOrderDate) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerEmail = customerEmail;
        this.noOfOrders = noOfOrders;
        this.mostRecentOrderDate = mostRecentOrderDate;
    }

    // --- Getters and Setters ---
    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public Integer getNoOfOrders() {
        return noOfOrders;
    }

    public void setNoOfOrders(Integer noOfOrders) {
        this.noOfOrders = noOfOrders;
    }

    public LocalDateTime getMostRecentOrderDate() {
        return mostRecentOrderDate;
    }

    public void setMostRecentOrderDate(LocalDateTime mostRecentOrderDate) {
        this.mostRecentOrderDate = mostRecentOrderDate;
    }
}
