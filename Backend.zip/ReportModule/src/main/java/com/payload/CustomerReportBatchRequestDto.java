package com.payload;

import java.util.List;

// This DTO is specifically designed for batch requests, containing a list of customerIds.
public class CustomerReportBatchRequestDto {
    private List<Long> customerIds;

    public CustomerReportBatchRequestDto() {
    }

    public CustomerReportBatchRequestDto(List<Long> customerIds) {
        this.customerIds = customerIds;
    }

    public List<Long> getCustomerIds() {
        return customerIds;
    }

    public void setCustomerIds(List<Long> customerIds) {
        this.customerIds = customerIds;
    }
}
