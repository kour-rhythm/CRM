package com.payload;
 
import java.time.LocalDateTime;
 
// This DTO will encapsulate the customer report, containing all customer behavior details
// that are fetched from the external CustomerDataModule.
public class CustomerReportDto {
 
    private Long customerId;
    private String customerName;
    private String customerEmail;
    private Integer noOfOrders;
    private LocalDateTime mostRecentOrderDate;
 
    // Default constructor (required by some frameworks like ModelMapper)
    public CustomerReportDto() {
    }
 
    // Constructor for creating a report DTO with all behavior details.
    // It's designed to mirror the CustomerBehaviorDetailDto from the external service.
    public CustomerReportDto(Long customerId, String customerName, String customerEmail,
                             Integer noOfOrders, LocalDateTime mostRecentOrderDate) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerEmail = customerEmail;
        this.noOfOrders = noOfOrders;
        this.mostRecentOrderDate = mostRecentOrderDate;
    }
 
    // --- Getters and Setters ---
 
    public Long getCustomerId() {
        return customerId;
    }
 
    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
 
    public String getCustomerName() {
        return customerName;
    }
 
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
 
    public String getCustomerEmail() {
        return customerEmail;
    }
 
    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }
 
    public Integer getNoOfOrders() {
        return noOfOrders;
    }
 
    public void setNoOfOrders(Integer noOfOrders) {
        this.noOfOrders = noOfOrders;
    }
 
    public LocalDateTime getMostRecentOrderDate() {
        return mostRecentOrderDate;
    }
 
    public void setMostRecentOrderDate(LocalDateTime mostRecentOrderDate) {
        this.mostRecentOrderDate = mostRecentOrderDate;
    }
}
 
 