package com.payload;

import java.time.LocalDate;

// DTO representing a Marketing Campaign fetched from the external Marketing Module.
// This DTO includes all fields of the Campaign entity from the external service,
// with campaignId now being a Long.
public class MarketingReportDto {

    private Long campaignID; // Changed to Long: Corresponds to 'campaignID' in the external Campaign entity
    private String name;        // Corresponds to 'name' in the external Campaign entity
    private LocalDate startDate; // Corresponds to 'startDate' in the external Campaign entity
    private LocalDate endDate;   // Corresponds to 'endDate' in the external Campaign entity
    private String type;        // Corresponds to 'type' (enum) in the external Campaign entity (as String)
    private String mailerSendCampaignId; // Corresponds to 'mailerSendCampaignId' in the external Campaign entity

    // Default constructor
    public MarketingReportDto() {
    }

    /**
     * Constructor with all fields expected from the external Marketing Module's Campaign entity.
     *
     * @param campaignId The ID of the campaign (Long).
     * @param name The name of the campaign.
     * @param startDate The start date of the campaign.
     * @param endDate The end date of the campaign.
     * @param type The type of the campaign.
     * @param mailerSendCampaignId The MailerSend campaign ID.
     */
    public MarketingReportDto(Long campaignID, String name, LocalDate startDate,
                              LocalDate endDate, String type, String mailerSendCampaignId) {
        this.campaignID = campaignID;
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.type = type;
        this.mailerSendCampaignId = mailerSendCampaignId;
    }

    // --- Getters and Setters ---

    public Long getcampaignID() {
        return campaignID;
    }

    public void setcampaignID(Long campaignID) {
        this.campaignID = campaignID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMailerSendCampaignId() {
        return mailerSendCampaignId;
    }

    public void setMailerSendCampaignId(String mailerSendCampaignId) {
        this.mailerSendCampaignId = mailerSendCampaignId;
    }
}
