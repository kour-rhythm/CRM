package com.payload;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * DTO representing a Marketing Report response.
 * This DTO is used for exposing locally stored marketing campaign report data via API.
 * It mirrors the structure of the MarketingReport entity, including all Campaign fields,
 * with campaignId now being a Long.
 */
public class MarketingReportResponseDto {

    private Long campaignId; // Changed to Long: Corresponds to campaignID and is the primary identifier for the report
    private String name;        // Corresponds to 'name' in Campaign
    private LocalDate startDate; // Corresponds to 'startDate' in Campaign
    private LocalDate endDate;   // Corresponds to 'endDate' in Campaign
    private String type;        // Corresponds to 'type' in Campaign (as String)
    private String mailerSendCampaignId; // Corresponds to 'mailerSendCampaignId' in Campaign
    private LocalDateTime generatedAt; // Timestamp when this report was generated/stored

    // Default constructor
    public MarketingReportResponseDto() {
    }

    /**
     * Constructor with all fields from the MarketingReport entity.
     *
     * @param campaignId The ID of the original campaign (also the report's ID) (Long).
     * @param name The name of the campaign.
     * @param startDate The start date of the campaign.
     * @param endDate The end date of the campaign.
     * @param type The type of the campaign.
     * @param mailerSendCampaignId The MailerSend campaign ID.
     * @param generatedAt The timestamp when this report was generated.
     */
    public MarketingReportResponseDto(Long campaignId, String name, LocalDate startDate,
                                      LocalDate endDate, String type, String mailerSendCampaignId,
                                      LocalDateTime generatedAt) {
        this.campaignId = campaignId;
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.type = type;
        this.mailerSendCampaignId = mailerSendCampaignId;
        this.generatedAt = generatedAt;
    }

    // --- Getters and Setters ---

    public Long getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Long campaignId) {
        this.campaignId = campaignId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMailerSendCampaignId() {
        return mailerSendCampaignId;
    }

    public void setMailerSendCampaignId(String mailerSendCampaignId) {
        this.mailerSendCampaignId = mailerSendCampaignId;
    }

    public LocalDateTime getGeneratedAt() {
        return generatedAt;
    }

    public void setGeneratedAt(LocalDateTime generatedAt) {
        this.generatedAt = generatedAt;
    }
}
