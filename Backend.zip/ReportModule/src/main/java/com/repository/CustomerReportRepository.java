package com.repository;

import com.entity.CustomerReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

// This repository will manage CustomerReport entities in the database.
// It extends JpaRepository to provide basic CRUD operations.
@Repository
public interface CustomerReportRepository extends JpaRepository<CustomerReport, Long> {
    // You might add custom query methods here if you need to find reports
    // by specific criteria, e.g., by customerId, or within a date range.
    Optional<CustomerReport> findByCustomerId(Long customerId);
}
