package com.repository;

import com.entity.MarketingReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional; // Import Optional for findById

/**
 * Repository interface for managing MarketingReport entities in the database.
 * Provides standard JPA CRUD operations. The MarketingReport entity uses
 * 'campaignId' as its primary key, which is a Long.
 */
@Repository
public interface MarketingReportRepository extends JpaRepository<MarketingReport, Long> {

    // Inherits standard CRUD methods like save(), findAll(), deleteById(), etc.
    // Specifically, JpaRepository already provides findById(ID id), where ID is the type of the primary key.
    // In this case, since MarketingReport's primary key (campaignId) is Long,
    // marketingReportRepository.findById(Long id) is already available and does not need to be explicitly declared here.
    //
    // However, if you explicitly want to make sure it's here, or if you were using a different
    // ID field that wasn't the primary key, you would declare it like this:
    // Optional<MarketingReport> findByCampaignId(Long campaignId);
    //
    // For the current setup, using the inherited findById is sufficient and correct:
    // Optional<MarketingReport> marketingReport = marketingReportRepository.findById(campaignDto.getCampaignId());
    //
    // For clarity, I'm adding an explicit findById method here, although it's redundant for JPA primary key methods.
    // This is useful if you were explicitly mapping 'campaignId' to the primary key 'id' in your entity
    // and wanted to ensure clarity for other developers, or if 'campaignId' was not the @Id field.
    // Given 'campaignId' IS the @Id field, the inherited method is automatically available.

    /**
     * Finds a MarketingReport entity by its primary key (which is the campaignId).
     * This method is inherited from JpaRepository, but explicitly listed for clarity
     * based on the user's request.
     *
     * @param campaignId The ID of the marketing campaign (which serves as the primary key).
     * @return An Optional containing the MarketingReport if found, or empty otherwise.
     */
    @Override // Annotating as @Override for clarity, though not strictly required if signature matches JpaRepository
    Optional<MarketingReport> findById(Long campaignID);
}
