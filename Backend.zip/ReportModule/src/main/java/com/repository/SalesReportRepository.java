package com.repository;

import com.entity.SalesReport; // Import the SalesReport entity
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository interface for managing SalesReport entities in the database.
 * It extends JpaRepository to provide basic CRUD (Create, Read, Update, Delete) operations
 * for SalesReport objects, with Long as the type of the primary key.
 */
@Repository
public interface SalesReportRepository extends JpaRepository<SalesReport, Long> {

    /**
     * Finds a SalesReport by its associated sales opportunity ID.
     * This is useful for checking if a report for a specific sales opportunity already exists.
     *
     * @param opportunityId The ID of the sales opportunity.
     * @return An Optional containing the SalesReport if found, otherwise empty.
     */
    Optional<SalesReport> findByOpportunityId(Long opportunityId);
}
