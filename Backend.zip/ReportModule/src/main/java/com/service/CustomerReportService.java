package com.service;

import com.payload.CustomerReportDto;
import reactor.core.publisher.Mono;
import java.util.List;

// Import the new BatchCustomerReportEntry for the modified method signature
import com.service.impl.CustomerReportServiceImpl.BatchCustomerReportEntry; // Adjust import based on where you place this DTO

// This interface defines the contract for operations related to customer reports.
public interface CustomerReportService {

    /**
     * Retrieves a detailed report for a single customer by their ID.
     *
     * @param customerId The ID of the customer.
     * @return A Mono emitting the CustomerReportDto if found, or an error.
     */
    Mono<CustomerReportDto> getCustomerReport(Long customerId);
    Mono<List<CustomerReportDto>> getAllCustomerReports();
    /**
     * Retrieves detailed reports for a list of customer IDs, providing status for each.
     *
     * @param customerIds A list of customer IDs.
     * @return A Mono emitting a List of BatchCustomerReportEntry, where each entry
     * indicates success or failure for a given customer ID.
     */
//    Mono<List<BatchCustomerReportEntry>> getCustomerReports(List<Long> customerIds); // MODIFIED RETURN TYPE
//
//    /**
//     * Retrieves detailed reports for all customers. This assumes the underlying external API
//     * can provide a non-paginated list of customer IDs, which are then used to fetch full reports.
//     *
//     * @return A Mono emitting a List of CustomerReportDto for all customers.
//     * Customers not found or causing errors during individual fetching will be skipped.
//     */
//    Mono<List<CustomerReportDto>> getAllCustomerReports();
//
//    /**
//     * Generates and saves a customer report for a given customer ID.
//     * This typically involves fetching the latest behavior details and persisting them.
//     *
//     * @param customerId The ID of the customer for whom to generate and save the report.
//     * @return A Mono emitting the saved CustomerReportDto.
//     */
    Mono<CustomerReportDto> generateAndSaveCustomerReport(Long customerId);
}
