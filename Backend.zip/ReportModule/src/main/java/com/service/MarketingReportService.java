package com.service;

import com.payload.MarketingReportDto; // DTO for campaign details from external module
import com.payload.MarketingReportResponseDto; // DTO for exposing local MarketingReport entities
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * This interface defines the contract for operations related to marketing reports.
 * It will interact with the external Marketing Module to fetch raw campaign data
 * and persist aggregated reports locally within the ReportGeneration service.
 */
public interface MarketingReportService {

    /**
     * Retrieves a detailed marketing campaign from the external Marketing Module by its ID.
     *
     * @param campaignId The ID of the marketing campaign (Long).
     * @return A Mono emitting the MarketingReportDto if found, or an error.
     */
    Mono<MarketingReportDto> getMarketingCampaign(Long campaignID); // Changed parameter type to Long

    /**
     * Retrieves all marketing campaigns from the external Marketing Module.
     *
     * @return A Flux emitting MarketingReportDto for each marketing campaign.
     */
    Flux<MarketingReportDto> getAllMarketingCampaigns(); // Added this method, assuming it will be implemented

    /**
     * Generates and saves a marketing report for a given campaign ID.
     * This typically involves fetching the latest campaign details from the external service
     * and persisting them as a MarketingReport entity in the local database.
     *
     * @param campaignId The ID of the marketing campaign for which to generate and save the report (Long).
     * @return A Mono emitting the saved MarketingReportResponseDto.
     */
    Mono<MarketingReportResponseDto> generateAndSaveMarketingReport(Long campaignID); // Changed parameter type to Long

    /**
     * Retrieves a saved Marketing Report from the local database by its ID.
     * The ID here refers to the campaignId which is now the primary key of the MarketingReport entity.
     *
     * @param campaignId The ID of the saved marketing report (which is the campaignId) (Long).
     * @return A Mono emitting the MarketingReportResponseDto if found, or an empty Mono.
     */
    Mono<MarketingReportResponseDto> getSavedMarketingReportById(Long campaignID); // Changed parameter type to Long

    /**
     * Retrieves all saved Marketing Reports from the local database.
     *
     * @return A Flux emitting MarketingReportResponseDto for each saved marketing report.
     */
    Flux<MarketingReportResponseDto> getAllSavedMarketingReports();
}
