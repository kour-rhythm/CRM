package com.service;

import com.payload.SalesOpportunityResponseDto; // DTO from the external Sales Opportunity Service
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * This interface defines the contract for operations related to sales reports.
 * It will interact with the external Sales Opportunity Service to fetch raw data
 * and potentially save aggregated reports locally.
 */
public interface SalesReportService {

    /**
     * Retrieves a detailed sales report for a single sales opportunity by its ID.
     * This involves calling the external Sales Opportunity Service.
     *
     * @param opportunityId The ID of the sales opportunity.
     * @return A Mono emitting the SalesOpportunityResponseDto if found, or an error.
     */
    Mono<SalesOpportunityResponseDto> getSalesReport(Long opportunityId);

    /**
     * Retrieves detailed sales reports for all sales opportunities.
     * This involves calling the external Sales Opportunity Service to get a list of all opportunities.
     *
     * @return A Flux emitting SalesOpportunityResponseDto for each sales opportunity.
     */
    Flux<SalesOpportunityResponseDto> getAllSalesReports();

    /**
     * Generates and saves a sales report for a given sales opportunity ID.
     * This typically involves fetching the latest sales opportunity details from the external service
     * and persisting them as a SalesReport entity in the local database.
     *
     * @param opportunityId The ID of the sales opportunity for which to generate and save the report.
     * @return A Mono emitting the saved SalesOpportunityResponseDto.
     */
    Mono<SalesOpportunityResponseDto> generateAndSaveSalesReport(Long opportunityId);

    // You might add more methods here as your reporting needs evolve,
    // e.g., getSalesReportsByDateRange(LocalDate startDate, LocalDate endDate)
}
