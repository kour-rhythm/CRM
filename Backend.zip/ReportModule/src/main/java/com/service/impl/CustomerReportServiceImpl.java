//package com.service.impl;
//
//import com.exception.CrmAPIException;
//import com.exception.ResourceNotFoundException;
//import com.payload.CustomerReportDto; // This remains an external DTO for the final report
//import com.service.CustomerReportService;
//import com.repository.CustomerReportRepository; // Import the repository
//import com.entity.CustomerReport; // Import the entity
//
//import org.modelmapper.ModelMapper;
//import org.springframework.http.HttpStatus;
//import org.springframework.stereotype.Service;
//import org.springframework.web.reactive.function.client.WebClient;
//import reactor.core.publisher.Flux;
//import reactor.core.publisher.Mono;
//import reactor.core.scheduler.Schedulers; // For offloading blocking calls
//
//import java.time.LocalDateTime; // Example for a timestamp field
//import java.util.List;
//import java.util.Map; // Example for a map of preferences
//import java.util.Optional;
//import java.util.stream.Collectors;
//
//@Service
//public class CustomerReportServiceImpl implements CustomerReportService {
//
//    private final ModelMapper mapper;
//    private final WebClient.Builder webClientBuilder; // Specific WebClient for CustomerDataModule
//    private final CustomerReportRepository customerReportRepository; // Inject the repository
//    // Internal DTOs for communication with CustomerModule
//    // These reflect the structure of basic customer data returned by CustomerModule's APIs
//    private static class CustomerDto {
//        private Long id;
//        private String name; // Assuming a 'name' field is present for basic customer info
//        // Add other basic customer fields as needed if returned by /api/customers endpoint
//        // e.g., private String email;
//
//        public Long getId() { return id; }
//        public void setId(Long id) { this.id = id; }
//        public String getName() { return name; }
//        public void setName(String name) { this.name = name; }
//        // Add getters/setters for other fields
//    }
//
//    // Internal DTO for /api/customers/{customerId}/behavior-details endpoint
//    // This DTO represents the detailed behavior data for a SINGLE customer.
//    // It does NOT involve pagination or sorting as it's for a direct, specific fetch.
//    private static class CustomerBehaviorDetailDto {
//        private Long customerId;
//        private String customerName;
//        private String customerEmailId;
//        private Integer noOfOrders;
//        private LocalDateTime mostRecentOrderDate;
//        // Example of other potential fields from behavior-details endpoint:
//        // private String lastInteractionType;
//        // private Double totalSpending;
//        // private Integer loyaltyPoints;
//        // private List<String> viewedProducts;
//        // private Map<String, String> preferences;
//
//        // Default constructor
//        public CustomerBehaviorDetailDto() {}
//
//        // Constructor with all fields
//        public CustomerBehaviorDetailDto(Long customerId, String customerName, String customerEmailId,
//                                         Integer noOfOrders, LocalDateTime mostRecentOrderDate) {
//            this.customerId = customerId;
//            this.customerName = customerName;
//            this.customerEmailId = customerEmailId;
//            this.noOfOrders = noOfOrders;
//            this.mostRecentOrderDate = mostRecentOrderDate;
//        }
//
//        // Getters and Setters
//        public Long getCustomerId() { return customerId; }
//        public void setCustomerId(Long customerId) { this.customerId = customerId; }
//        public String getCustomerName() { return customerName; }
//        public void setCustomerName(String customerName) { this.customerName = customerName; }
//        public String getCustomerEmailId() { return customerEmailId; }
//        public void setCustomerEmailId(String customerEmailId) { this.customerEmailId = customerEmailId; }
//        public Integer getNoOfOrders() { return noOfOrders; }
//        public void setNoOfOrders(Integer noOfOrders) { this.noOfOrders = noOfOrders; }
//        public LocalDateTime getMostRecentOrderDate() { return mostRecentOrderDate; }
//        public void setMostRecentOrderDate(LocalDateTime mostRecentOrderDate) { this.mostRecentOrderDate = mostRecentOrderDate; }
//        // Add getters/setters for other fields if present in CustomerModule's response
//    }
//    public CustomerReportServiceImpl(CustomerReportRepository customerReportRepository,
//            ModelMapper mapper,
//            WebClient.Builder webClientBuilder) {
//this.customerReportRepository = customerReportRepository;
//this.mapper = mapper;
//this.webClientBuilder = webClientBuilder;
//}
////    public CustomerReportServiceImpl(ModelMapper mapper, WebClient.Builder webClientBuilder,
////                                     CustomerReportRepository customerReportRepository) { // Inject repository
////        this.mapper = mapper;
////        // Build a WebClient instance specifically for the CustomerDataModule
//////        this.webClientCustomerDataModule = webClientBuilder.baseUrl("http://CustomerModule").build();
////        this.customerReportRepository = customerReportRepository; // Initialize repository
////    }
//
//    @Override
//    public Mono<CustomerReportDto> getCustomerReport(Long customerId) {
//        // Use WebClient to call the external CustomerDataModule for behavior details.
//    	WebClient customerReportWebClient = webClientBuilder.baseUrl("http://CustomerModule").build();
//        return customerReportWebClient.get()
//                .uri("/api/customers/{customerId}/behavior-details", customerId)
//                .retrieve()
//                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
//                    clientResponse.bodyToMono(String.class)
//                        .flatMap(errorBody -> {
//                            if (clientResponse.statusCode().equals(HttpStatus.NOT_FOUND)) {
//                                return Mono.error(new ResourceNotFoundException("Customer", "id", customerId));
//                            } else {
//                                // For other client/server errors from external service, wrap in CrmAPIException
//                                return Mono.error(new CrmAPIException(clientResponse.statusCode(),
//                                        "Error from Customer Data Module: " + errorBody));
//                            }
//                        })
//                )
//                .bodyToMono(CustomerBehaviorDetailDto.class) // Expecting the full DTO from external service
//                .map(customerBehaviorDetailDto -> {
//                    // Map the received CustomerBehaviorDetailDto directly to CustomerReportDto.
//                    return mapper.map(customerBehaviorDetailDto, CustomerReportDto.class);
//                });
//    }
//
//    @Override
//    public Mono<List<CustomerReportDto>> getCustomerReports(List<Long> customerIds) {
//        // This method fetches basic CustomerDto for each ID and then individual behavior details.
//
//        // Build the URI with repeated 'ids=' parameters for @RequestParam List<Long>
//        String idsQueryParam = customerIds.stream()
//            .map(id -> "ids=" + id)
//            .collect(Collectors.joining("&"));
//        WebClient customerIdWebClient = webClientBuilder.baseUrl("http://CustomerModule").build();
//        return customerIdWebClient.get()
//                .uri(uriBuilder -> uriBuilder.path("/api/customers/by-ids")
//                                             .query(idsQueryParam)
//                                             .build())
//                .retrieve()
//                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
//                    clientResponse.bodyToMono(String.class)
//                        .flatMap(errorBody -> Mono.error(new CrmAPIException(clientResponse.statusCode(),
//                                "Error from Customer Data Module (batch IDs fetch): " + errorBody)))
//                )
//                .bodyToFlux(CustomerDto.class) // Expecting a Flux of basic CustomerDto (the inner class)
//                .flatMap(customerDto -> this.getCustomerReport(customerDto.getId()) // Reuse single customer logic for full details
//                        .onErrorResume(ResourceNotFoundException.class, ex -> {
//                            System.err.println("Batch Report: Customer with ID " + customerDto.getId() + " not found: " + ex.getMessage());
//                            return Mono.empty(); // Skip this customer in the final list
//                        })
//                        .onErrorResume(CrmAPIException.class, ex -> {
//                            System.err.println("Batch Report: Error fetching report for customer ID " + customerDto.getId() + ": " + ex.getMessage());
//                            return Mono.empty(); // Skip this customer in the final list
//                        })
//                        .onErrorResume(Exception.class, ex -> {
//                            System.err.println("Batch Report: Unexpected error fetching report for customer ID " + customerDto.getId() + ": " + ex.getMessage());
//                            return Mono.empty(); // Skip this customer in the final list
//                        })
//                )
//                .collectList(); // Collect all successful results into a List
//    }
//
//    @Override
//    public Mono<List<CustomerReportDto>> getAllCustomerReports() {
//        // This method directly gets a Flux of CustomerDto from /api/customers endpoint.
//        // It assumes the /api/customers endpoint can return a flat list of customers
//        // without pagination when no pagination parameters are explicitly sent.
//        // If CustomerModule's /api/customers endpoint *always* paginates, and you need all,
//        // you would need to implement an iterative fetching mechanism (e.g., using expand or recursion).
//    	WebClient customerAllWebClient = webClientBuilder.baseUrl("http://CustomerModule").build();
//        return customerAllWebClient.get()
//                .uri("/api/customers") // Call without page/size parameters as per "no pagination" request
//                .retrieve()
//                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
//                    clientResponse.bodyToMono(String.class)
//                        .flatMap(errorBody -> Mono.error(new CrmAPIException(clientResponse.statusCode(),
//                                "Error from Customer Data Module (fetching all customer IDs): " + errorBody)))
//                )
//                .bodyToFlux(CustomerDto.class) // Directly expect a Flux of CustomerDto
//                .flatMap(customerDto -> getCustomerReport(customerDto.getId()) // For each CustomerDto, get its full report
//                    .onErrorResume(ResourceNotFoundException.class, ex -> {
//                        System.err.println("All Reports: Customer with ID " + customerDto.getId() + " not found while fetching behavior details: " + ex.getMessage());
//                        return Mono.empty(); // Skip this customer in the final list
//                    })
//                    .onErrorResume(CrmAPIException.class, ex -> {
//                        System.err.println("All Reports: Error fetching behavior details for customer ID " + customerDto.getId() + ": " + ex.getMessage());
//                        return Mono.empty(); // Skip this customer in the final list
//                    })
//                    .onErrorResume(Exception.class, ex -> {
//                        System.err.println("All Reports: Unexpected error fetching behavior details for customer ID " + customerDto.getId() + ": " + ex.getMessage());
//                        return Mono.empty(); // Skip this customer in the final list
//                    })
//                )
//                .collectList(); // Collect all successful CustomerReportDto into a List
//    }
//
//    @Override
//    public Mono<CustomerReportDto> generateAndSaveCustomerReport(Long customerId) {
//        return getCustomerReport(customerId) // First, get the behavior details
//                .flatMap(reportDto -> Mono.fromCallable(() -> { // Then, perform the blocking save operation
//                    // Check if a report for this customer already exists to update it,
//                    // or create a new one.
//                    Optional<CustomerReport> existingReportOptional = customerReportRepository.findByCustomerId(reportDto.getCustomerId());
//                    CustomerReport reportEntity;
//
//                    if (existingReportOptional.isPresent()) {
//                        reportEntity = existingReportOptional.get();
//                        // Update existing fields from the new reportDto
//                        mapper.map(reportDto, reportEntity); // Map DTO to existing entity
//                        reportEntity.setGeneratedAt(LocalDateTime.now()); // Update timestamp
//                    } else {
//                        reportEntity = mapper.map(reportDto, CustomerReport.class); // Map DTO to new entity
//                        // generatedAt is set in the CustomerReport entity's constructor
//                    }
//
//                    CustomerReport savedEntity = customerReportRepository.save(reportEntity); // Blocking JPA save
//                    return mapper.map(savedEntity, CustomerReportDto.class); // Map back to DTO
//                }).subscribeOn(Schedulers.boundedElastic())) // Offload to a dedicated thread pool for blocking ops
//                .onErrorResume(ResourceNotFoundException.class, ex -> {
//                    System.err.println("Generate and Save Report: Customer " + customerId + " not found: " + ex.getMessage());
//                    return Mono.error(ex); // Re-throw or handle as per your needs
//                })
//                .onErrorResume(CrmAPIException.class, ex -> {
//                    System.err.println("Generate and Save Report API Error for customer " + customerId + ": " + ex.getMessage());
//                    return Mono.error(ex);
//                })
//                .onErrorResume(Exception.class, ex -> {
//                    System.err.println("Unexpected error generating/saving report for customer " + customerId + ": " + ex.getMessage());
//                    return Mono.error(ex);
//                });
//    }
//}
package com.service.impl; // Corrected package name based on your file paths

import com.exception.CrmAPIException;
import com.exception.ResourceNotFoundException;
import com.payload.CustomerReportDto;
import com.service.CustomerReportService;
import com.repository.CustomerReportRepository;
import com.entity.CustomerReport;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CustomerReportServiceImpl implements CustomerReportService {

    private final ModelMapper mapper;
    private final WebClient webClientCustomerDataModule;
    private final CustomerReportRepository customerReportRepository;

    // Internal DTOs for communication with CustomerModule
    private static class CustomerDto {
        private Long id;
        private String name;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
    }

    private static class CustomerBehaviorDetailDto {
        private Long customerId;
        private String customerName;
        private String customerEmail;
        private Integer noOfOrders;
        private LocalDateTime mostRecentOrderDate;

        public CustomerBehaviorDetailDto() {}

        public CustomerBehaviorDetailDto(Long customerId, String customerName, String customerEmail,
                                         Integer noOfOrders, LocalDateTime mostRecentOrderDate) {
            this.customerId = customerId;
            this.customerName = customerName;
            this.customerEmail = customerEmail;
            this.noOfOrders = noOfOrders;
            this.mostRecentOrderDate = mostRecentOrderDate;
        }

        public Long getCustomerId() { return customerId; }
        public void setCustomerId(Long customerId) { this.customerId = customerId; }
        public String getCustomerName() { return customerName; }
        public void setCustomerName(String customerName) { this.customerName = customerName; }
        public String getCustomerEmail() { return customerEmail; }
        public void setCustomerEmail(String customerEmail) { this.customerEmail = customerEmail; }
        public Integer getNoOfOrders() { return noOfOrders; }
        public void setNoOfOrders(Integer noOfOrders) { this.noOfOrders = noOfOrders; }
        public LocalDateTime getMostRecentOrderDate() { return mostRecentOrderDate; }
        public void setMostRecentOrderDate(LocalDateTime mostRecentOrderDate) { this.mostRecentOrderDate = mostRecentOrderDate; }
    }

    // NEW: Internal DTO to hold results for each customer in a batch report, including errors.
    public static class BatchCustomerReportEntry {
        private Long customerId;
        private CustomerReportDto report; // Will be null if an error occurred
        private String errorMessage;     // Will contain error message if an error occurred
        private boolean success;

        public BatchCustomerReportEntry(Long customerId, CustomerReportDto report, String errorMessage, boolean success) {
            this.customerId = customerId;
            this.report = report;
            this.errorMessage = errorMessage;
            this.success = success;
        }

        // Getters
        public Long getCustomerId() { return customerId; }
        public CustomerReportDto getReport() { return report; }
        public String getErrorMessage() { return errorMessage; }
        public boolean isSuccess() { return success; }
    }


    public CustomerReportServiceImpl(CustomerReportRepository customerReportRepository,
                                     ModelMapper mapper,
                                     WebClient.Builder webClientBuilder) {
        this.customerReportRepository = customerReportRepository;
        this.mapper = mapper;
        this.webClientCustomerDataModule = webClientBuilder.baseUrl("http://CustomerModule").build();
    }

    @Override
    public Mono<CustomerReportDto> getCustomerReport(Long customerId) {
        return webClientCustomerDataModule.get()
                .uri("/api/customers/{customerId}/behavior-details", customerId)
                .retrieve()
                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
                    clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> {
                            if (clientResponse.statusCode().equals(HttpStatus.NOT_FOUND)) {
                                return Mono.error(new ResourceNotFoundException("Customer", "id", customerId));
                            } else {
                                return Mono.error(new CrmAPIException(clientResponse.statusCode(),
                                        "Error from Customer Data Module: " + errorBody));
                            }
                        })
                )
                .bodyToMono(CustomerBehaviorDetailDto.class)
                .map(customerBehaviorDetailDto -> {
                    return mapper.map(customerBehaviorDetailDto, CustomerReportDto.class);
                });
    }
    @Override
    public Mono<List<CustomerReportDto>> getAllCustomerReports() {
        // Corrected: Using 'map' instead of 'flatMap' for synchronous conversion of each item.
        // Flux.fromIterable is used to convert the blocking List result from JpaRepository.findAll()
        // into a reactive Flux.
        return Flux.fromIterable(customerReportRepository.findAll())
                   .map(this::convertToDto)
                   .collectList();
    }
    public CustomerReportDto convertToDto(CustomerReport entity) {
        CustomerReportDto dto = new CustomerReportDto();
        // Removed: dto.setReportId(entity.getId()); as CustomerReportDto does not have a reportId field.
        dto.setCustomerId(entity.getCustomerId());
        dto.setCustomerName(entity.getCustomerName());
        dto.setCustomerEmail(entity.getCustomerEmail()); // Map customerEmail
        dto.setNoOfOrders(entity.getNoOfOrders()); // Map noOfOrders
        dto.setMostRecentOrderDate(entity.getMostRecentOrderDate()); // Map and convert to string
        return dto;
    }

    // Helper method to convert DTO to Entity (if needed, e.g., for saving DTOs)
    private CustomerReport convertToEntity(CustomerReportDto dto) {
        CustomerReport entity = new CustomerReport();
        // Removed: if (dto.getReportId() != null) { entity.setId(dto.getReportId()); }
        // as CustomerReportDto does not have a reportId field.
        entity.setCustomerId(dto.getCustomerId());
        entity.setCustomerName(dto.getCustomerName());
        entity.setCustomerEmail(dto.getCustomerEmail());
        entity.setNoOfOrders(dto.getNoOfOrders());
        entity.setMostRecentOrderDate(dto.getMostRecentOrderDate());
        // generatedAt will be set by the entity's default constructor or service logic
        return entity;
    }

//    @Override
//    public Mono<List<BatchCustomerReportEntry>> getCustomerReports(List<Long> customerIds) { // MODIFIED RETURN TYPE
//        String idsQueryParam = customerIds.stream()
//            .map(id -> "ids=" + id)
//            .collect(Collectors.joining("&"));
//
//        return webClientCustomerDataModule.get()
//                .uri(uriBuilder -> uriBuilder.path("/api/customers/by-ids")
//                                             .query(idsQueryParam)
//                                             .build())
//                .retrieve()
//                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
//                    clientResponse.bodyToMono(String.class)
//                        .flatMap(errorBody -> Mono.error(new CrmAPIException(clientResponse.statusCode(),
//                                "Error from Customer Data Module (batch IDs fetch): " + errorBody)))
//                )
//                .bodyToFlux(CustomerDto.class)
//                .flatMap(customerDto -> this.getCustomerReport(customerDto.getId()) // Reuse single customer logic for full details
//                        .map(report -> new BatchCustomerReportEntry(customerDto.getId(), report, null, true)) // Success case
//                        .onErrorResume(ResourceNotFoundException.class, ex -> {
//                            System.err.println("Batch Report: Customer with ID " + customerDto.getId() + " not found: " + ex.getMessage());
//                            return Mono.just(new BatchCustomerReportEntry(customerDto.getId(), null, ex.getMessage(), false)); // Error case
//                        })
//                        .onErrorResume(CrmAPIException.class, ex -> {
//                            System.err.println("Batch Report: Error fetching report for customer ID " + customerDto.getId() + ": " + ex.getMessage());
//                            return Mono.just(new BatchCustomerReportEntry(customerDto.getId(), null, ex.getMessage(), false)); // Error case
//                        })
//                        .onErrorResume(Exception.class, ex -> {
//                            System.err.println("Batch Report: Unexpected error fetching report for customer ID " + customerDto.getId() + ": " + ex.getMessage());
//                            return Mono.just(new BatchCustomerReportEntry(customerDto.getId(), null, ex.getMessage(), false)); // Error case
//                        })
//                )
//                .collectList(); // Collect all results (successes and errors) into a List
//    }

//    @Override
//    public Mono<List<CustomerReportDto>> getAllCustomerReports() {
//        return webClientCustomerDataModule.get()
//                .uri("/api/customers")
//                .retrieve()
//                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
//                    clientResponse.bodyToMono(String.class)
//                        .flatMap(errorBody -> Mono.error(new CrmAPIException(clientResponse.statusCode(),
//                                "Error from Customer Data Module (fetching all customer IDs): " + errorBody)))
//                )
//                .bodyToFlux(CustomerDto.class)
//                .flatMap(customerDto -> getCustomerReport(customerDto.getId())
//                    .onErrorResume(ResourceNotFoundException.class, ex -> {
//                        System.err.println("All Reports: Customer with ID " + customerDto.getId() + " not found while fetching behavior details: " + ex.getMessage());
//                        return Mono.empty();
//                    })
//                    .onErrorResume(CrmAPIException.class, ex -> {
//                        System.err.println("All Reports: Error fetching behavior details for customer ID " + customerDto.getId() + ": " + ex.getMessage());
//                        return Mono.empty();
//                    })
//                    .onErrorResume(Exception.class, ex -> {
//                        System.err.println("All Reports: Unexpected error fetching behavior details for customer ID " + customerDto.getId() + ": " + ex.getMessage());
//                        return Mono.empty();
//                    })
//                )
//                .collectList();
//    }

    @Override
    public Mono<CustomerReportDto> generateAndSaveCustomerReport(Long customerId) {
        return getCustomerReport(customerId)
                .flatMap(reportDto -> Mono.fromCallable(() -> {
                    Optional<CustomerReport> existingReportOptional = customerReportRepository.findByCustomerId(reportDto.getCustomerId());
                    CustomerReport reportEntity;

                    if (existingReportOptional.isPresent()) {
                        reportEntity = existingReportOptional.get();
                        mapper.map(reportDto, reportEntity);
                        reportEntity.setGeneratedAt(LocalDateTime.now());
                    } else {
                        reportEntity = mapper.map(reportDto, CustomerReport.class);
                    }

                    CustomerReport savedEntity = customerReportRepository.save(reportEntity);
                    return mapper.map(savedEntity, CustomerReportDto.class);
                }).subscribeOn(Schedulers.boundedElastic()))
                .onErrorResume(ResourceNotFoundException.class, ex -> {
                    System.err.println("Generate and Save Report: Customer " + customerId + " not found: " + ex.getMessage());
                    return Mono.error(ex);
                })
                .onErrorResume(CrmAPIException.class, ex -> {
                    System.err.println("Generate and Save Report API Error for customer " + customerId + ": " + ex.getMessage());
                    return Mono.error(ex);
                })
                .onErrorResume(Exception.class, ex -> {
                    System.err.println("Unexpected error generating/saving report for customer " + customerId + ": " + ex.getMessage());
                    return Mono.error(ex);
                });
    }
}
