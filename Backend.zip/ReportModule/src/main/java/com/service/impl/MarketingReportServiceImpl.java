package com.service.impl;

import com.entity.MarketingReport;
import com.exception.CrmAPIException;
import com.exception.ResourceNotFoundException;
import com.payload.MarketingReportDto; // DTO for campaign details from external module
import com.payload.MarketingReportResponseDto; // DTO for exposing local MarketingReport entities
import com.repository.MarketingReportRepository;
import com.service.MarketingReportService;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers; // For offloading blocking operations

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Implementation of the MarketingReportService interface.
 * This service handles fetching campaign data from an external Marketing Module
 * and managing the persistence and retrieval of MarketingReport entities locally.
 */
@Service
public class MarketingReportServiceImpl implements MarketingReportService {

    private final ModelMapper mapper;
    // WebClient instance specifically configured for the external Marketing Module Service
    private final WebClient webClientMarketingModule;
    private final MarketingReportRepository marketingReportRepository;

    /**
     * Constructor for MarketingReportServiceImpl.
     * Spring will automatically inject dependencies.
     *
     * @param mapper ModelMapper for DTO to Entity conversions.
     * @param webClientBuilder WebClient.Builder for creating WebClient instances.
     * @param marketingReportRepository Repository for MarketingReport entities.
     */
    public MarketingReportServiceImpl(ModelMapper mapper,
                                      WebClient.Builder webClientBuilder,
                                      MarketingReportRepository marketingReportRepository) {
        this.mapper = mapper;
        // Assume the Marketing Module Service is registered as "MarketingModule" in Eureka.
        this.webClientMarketingModule = webClientBuilder.baseUrl("http://MarketingModule").build();
        this.marketingReportRepository = marketingReportRepository;
    }

    /**
     * Retrieves a detailed marketing campaign from the external Marketing Module by its ID.
     * This method directly calls the external service.
     *
     * @param campaignId The ID of the marketing campaign (Long).
     * @return A Mono emitting the MarketingReportDto if found, or an error.
     */
    @Override
    public Mono<MarketingReportDto> getMarketingCampaign(Long campaignID) {
        return webClientMarketingModule.get()
                .uri("/api/marketing/campaigns/{id}", campaignID) // Endpoint from MarketingController
                .retrieve()
                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
                    clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> {
                            if (clientResponse.statusCode().equals(HttpStatus.NOT_FOUND)) {
                                // If the external service returns 404, throw ResourceNotFoundException
                                return Mono.error(new ResourceNotFoundException("Marketing Campaign", "id", campaignID)); // Use campaignId directly as Long
                            } else {
                                // For other errors from external service, throw CrmAPIException
                                return Mono.error(new CrmAPIException(clientResponse.statusCode(),
                                        "Error from Marketing Module (single campaign): " + errorBody));
                            }
                        })
                )
                .bodyToMono(MarketingReportDto.class); // Expecting the MarketingReportDto from external service
    }

    /**
     * Retrieves all marketing campaigns from the external Marketing Module.
     *
     * @return A Flux emitting MarketingReportDto for each marketing campaign.
     */
    @Override
    public Flux<MarketingReportDto> getAllMarketingCampaigns() {
        return webClientMarketingModule.get()
                .uri("/api/marketing/campaigns") // Assuming an endpoint to get all campaigns
                .retrieve()
                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
                    clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> Mono.error(new CrmAPIException(clientResponse.statusCode(),
                                "Error from Marketing Module (fetching all campaigns): " + errorBody)))
                )
                .bodyToFlux(MarketingReportDto.class) // Expecting a Flux of DTOs
                .onErrorResume(Exception.class, ex -> {
                    System.err.println("Error fetching all marketing campaigns: " + ex.getMessage());
                    return Flux.empty();
                });
    }

    /**
     * Generates and saves a marketing report for a given campaign ID.
     * This method fetches the latest campaign details from the external service
     * and persists them as a MarketingReport entity in the local database.
     * It handles updates if a report for the campaign already exists.
     *
     * @param campaignId The ID of the marketing campaign for which to generate and save the report (Long).
     * @return A Mono emitting the saved MarketingReportResponseDto.
     */
    @Override
    public Mono<MarketingReportResponseDto> generateAndSaveMarketingReport(Long campaignID) {
        return getMarketingCampaign(campaignID) // First, fetch the marketing campaign details
                .flatMap(campaignDto -> {
                    // CRITICAL: Check if the campaignId from the external DTO is null.
                    // If the external service returns a DTO with a null ID, it's an invalid state.
                    if (campaignDto.getcampaignID() == null) {
                        return Mono.error(new CrmAPIException(HttpStatus.INTERNAL_SERVER_ERROR,
                                "External Marketing Module returned a campaign with a null ID for campaignId: " + campaignID + ". Cannot save report."));
                    }

                    return Mono.fromCallable(() -> { // Then, perform the blocking save operation
                        // Check if a report for this marketing campaign already exists to update it,
                        // or create a new one. Use findById as campaignId is now the PK.
                        Optional<MarketingReport> existingReportOptional = marketingReportRepository.findById(campaignDto.getcampaignID());
                        MarketingReport marketingReportEntity;

                        if (existingReportOptional.isPresent()) {
                            marketingReportEntity = existingReportOptional.get();
                            // Update existing fields from the new campaignDto
                            // campaignId is already the PK and mapped, no need to set explicitly again unless value changes
                            marketingReportEntity.setName(campaignDto.getName());
                            marketingReportEntity.setStartDate(campaignDto.getStartDate());
                            marketingReportEntity.setEndDate(campaignDto.getEndDate());
                            marketingReportEntity.setType(campaignDto.getType());
                            marketingReportEntity.setMailerSendCampaignId(campaignDto.getMailerSendCampaignId());
                            marketingReportEntity.setGeneratedAt(LocalDateTime.now()); // Update timestamp
                        } else {
                            // Create a new MarketingReport entity.
                            marketingReportEntity = new MarketingReport(
                                campaignDto.getcampaignID(),
                                campaignDto.getName(),
                                campaignDto.getStartDate(),
                                campaignDto.getEndDate(),
                                campaignDto.getType(),
                                campaignDto.getMailerSendCampaignId()
                            );
                            // generatedAt is set in the MarketingReport entity's constructor
                        }

                        // Perform the blocking JPA save operation
                        MarketingReport savedEntity = marketingReportRepository.save(marketingReportEntity);
                        return mapper.map(savedEntity, MarketingReportResponseDto.class); // Map back to DTO for response
                    }).subscribeOn(Schedulers.boundedElastic()); // Offload blocking database operation to a dedicated thread pool
                })
                .onErrorResume(ResourceNotFoundException.class, ex -> {
                    System.err.println("Generate and Save Marketing Report: Marketing Campaign " + campaignID + " not found: " + ex.getMessage());
                    return Mono.error(ex); // Re-throw the original exception for controller to handle 400/404
                })
                .onErrorResume(CrmAPIException.class, ex -> {
                    System.err.println("Generate and Save Marketing Report API Error for campaign " + campaignID + ": " + ex.getMessage());
                    return Mono.error(ex); // Re-throw for controller to handle
                })
                .onErrorResume(Exception.class, ex -> {
                    System.err.println("Unexpected error generating/saving marketing report for campaign " + campaignID + ": " + ex.getMessage());
                    return Mono.error(ex); // Re-throw for controller to handle 500
                });
    }

    /**
     * Retrieves a saved Marketing Report from the local database by its ID.
     * The ID here refers to the campaignId which is now the primary key of the MarketingReport.
     *
     * @param campaignId The ID of the saved marketing report (which is the campaignId) (Long).
     * @return A Mono emitting the MarketingReportResponseDto if found, or an empty Mono.
     */
    @Override
    public Mono<MarketingReportResponseDto> getSavedMarketingReportById(Long campaignId) { // Changed parameter type to Long
        return Mono.fromCallable(() -> marketingReportRepository.findById(campaignId)
                .map(entity -> mapper.map(entity, MarketingReportResponseDto.class))
                .orElseThrow(() -> new ResourceNotFoundException("Marketing Report", "id", campaignId)))
            .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Retrieves all saved Marketing Reports from the local database.
     *
     * @return A Flux emitting MarketingReportResponseDto for each saved marketing report.
     */
    @Override
    public Flux<MarketingReportResponseDto> getAllSavedMarketingReports() {
        return Mono.fromCallable(() -> marketingReportRepository.findAll())
                .subscribeOn(Schedulers.boundedElastic())
                .flatMapMany(Flux::fromIterable)
                .map(entity -> mapper.map(entity, MarketingReportResponseDto.class));
    }
}
