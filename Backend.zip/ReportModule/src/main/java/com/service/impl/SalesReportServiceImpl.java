package com.service.impl;

import com.entity.SalesReport;
import com.exception.CrmAPIException;
import com.exception.ResourceNotFoundException;
import com.payload.SalesOpportunityResponseDto;
import com.repository.SalesReportRepository;
import com.service.SalesReportService;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers; // For offloading blocking operations

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Implementation of the SalesReportService interface.
 * This service is responsible for fetching sales opportunity data from an external
 * Sales Opportunity Service and transforming/persisting it as sales reports.
 */
@Service
public class SalesReportServiceImpl implements SalesReportService {

    private final ModelMapper mapper;
    // WebClient instance specifically configured for the external Sales Opportunity Service
    private final WebClient webClientSalesOpportunityModule;
    private final SalesReportRepository salesReportRepository;

    /**
     * Constructor for SalesReportServiceImpl.
     * Spring will automatically inject dependencies.
     *
     * @param mapper ModelMapper for DTO to Entity conversions.
     * @param webClientBuilder WebClient.Builder for creating WebClient instances.
     * @param salesReportRepository Repository for SalesReport entities.
     */
    public SalesReportServiceImpl(ModelMapper mapper,
                                  WebClient.Builder webClientBuilder,
                                  SalesReportRepository salesReportRepository) {
        this.mapper = mapper;
        // Assume the Sales Opportunity Service is registered as "SalesOpportunityModule" in Eureka
        this.webClientSalesOpportunityModule = webClientBuilder.baseUrl("http://SalesOpportunitiesApplication").build();
        this.salesReportRepository = salesReportRepository;
    }

    /**
     * Retrieves a detailed sales report for a single sales opportunity by its ID
     * from the external Sales Opportunity Service.
     *
     * @param opportunityId The ID of the sales opportunity.
     * @return A Mono emitting the SalesOpportunityResponseDto if found, or an error.
     */
    @Override
    public Mono<SalesOpportunityResponseDto> getSalesReport(Long opportunityId) {
        return webClientSalesOpportunityModule.get()
                .uri("/api/salesopportunities/{id}", opportunityId) // Endpoint from SalesOpportunityController
                .retrieve()
                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
                    clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> {
                            if (clientResponse.statusCode().equals(HttpStatus.NOT_FOUND)) {
                                return Mono.error(new ResourceNotFoundException("Sales Opportunity", "id", opportunityId));
                            } else {
                                return Mono.error(new CrmAPIException(clientResponse.statusCode(),
                                        "Error from Sales Opportunity Module (single report): " + errorBody));
                            }
                        })
                )
                .bodyToMono(SalesOpportunityResponseDto.class); // Expecting the full DTO from external service
    }

    /**
     * Retrieves detailed sales reports for all sales opportunities
     * from the external Sales Opportunity Service.
     *
     * @return A Flux emitting SalesOpportunityResponseDto for each sales opportunity.
     */
    @Override
    public Flux<SalesOpportunityResponseDto> getAllSalesReports() {
        // Calls the external Sales Opportunity Service to get a stream of all opportunities.
        // Assumes /api/salesopportunities endpoint returns a list of SalesOpportunityResponseDto.
        return webClientSalesOpportunityModule.get()
                .uri("/api/salesopportunities") // Endpoint from SalesOpportunityController for all opportunities
                .retrieve()
                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
                    clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> Mono.error(new CrmAPIException(clientResponse.statusCode(),
                                "Error from Sales Opportunity Module (fetching all opportunities): " + errorBody)))
                )
                .bodyToFlux(SalesOpportunityResponseDto.class) // Expecting a Flux of DTOs
                .onErrorResume(Exception.class, ex -> {
                    System.err.println("Error fetching all sales opportunities: " + ex.getMessage());
                    return Flux.empty(); // Return empty Flux on error
                });
    }

    /**
     * Generates and saves a sales report for a given sales opportunity ID.
     * This method fetches the latest sales opportunity details from the external service
     * and persists them as a SalesReport entity in the local database.
     * It handles updates if a report for the opportunity already exists.
     *
     * @param opportunityId The ID of the sales opportunity for which to generate and save the report.
     * @return A Mono emitting the saved SalesOpportunityResponseDto.
     */
    @Override
    public Mono<SalesOpportunityResponseDto> generateAndSaveSalesReport(Long opportunityId) {
        return getSalesReport(opportunityId) // First, fetch the sales opportunity details
                .flatMap(opportunityDto -> Mono.fromCallable(() -> { // Then, perform the blocking save operation
                    // Check if a report for this sales opportunity already exists to update it,
                    // or create a new one.
                    Optional<SalesReport> existingReportOptional = salesReportRepository.findByOpportunityId(opportunityDto.getId());
                    SalesReport salesReportEntity;

                    if (existingReportOptional.isPresent()) {
                        salesReportEntity = existingReportOptional.get();
                        // Update existing fields from the new opportunityDto
                        mapper.map(opportunityDto, salesReportEntity); // Map DTO to existing entity
                        salesReportEntity.setGeneratedAt(LocalDateTime.now()); // Update timestamp
                    } else {
                        // Create a new SalesReport entity.
                        // Ensure SalesOpportunityResponseDto fields map correctly to SalesReport entity fields.
                        salesReportEntity = mapper.map(opportunityDto, SalesReport.class);
                        // Make sure to explicitly set the opportunityId if ModelMapper doesn't handle it
                        salesReportEntity.setOpportunityId(opportunityDto.getId());
                        // generatedAt is set in the SalesReport entity's constructor
                    }

                    // Perform the blocking JPA save operation
                    SalesReport savedEntity = salesReportRepository.save(salesReportEntity);
                    return mapper.map(savedEntity, SalesOpportunityResponseDto.class); // Map back to DTO for response
                }).subscribeOn(Schedulers.boundedElastic())) // Offload blocking database operation to a dedicated thread pool
                .onErrorResume(ResourceNotFoundException.class, ex -> {
                    System.err.println("Generate and Save Sales Report: Sales Opportunity " + opportunityId + " not found: " + ex.getMessage());
                    return Mono.error(ex); // Re-throw the original exception
                })
                .onErrorResume(CrmAPIException.class, ex -> {
                    System.err.println("Generate and Save Sales Report API Error for opportunity " + opportunityId + ": " + ex.getMessage());
                    return Mono.error(ex);
                })
                .onErrorResume(Exception.class, ex -> {
                    System.err.println("Unexpected error generating/saving sales report for opportunity " + opportunityId + ": " + ex.getMessage());
                    return Mono.error(ex);
                });
    }
}
